/* English 5000 Service Worker — V5.16.17
   核心檔案一定要快取成功；圖示缺少時不影響離線安裝。
   新版安裝時略過瀏覽器 HTTP 快取，啟用後立即接管並清除舊版快取，避免卡在舊版。 */
const C='english-5000-v5-16-20';
const CORE=['./','index.html','styles.css','app.js','data.js','manifest.webmanifest'];
const OPT=['icon.svg','icon-180.png','icon-192.png','icon-512.png'];
const fresh=u=>new Request(u,{cache:'reload'});
async function install(){
  const c=await caches.open(C);
  await c.addAll(CORE.map(fresh));
  await Promise.all(OPT.map(u=>fetch(fresh(u)).then(r=>r.ok?c.put(u,r):null).catch(()=>null)));
  await self.skipWaiting();
}
async function activate(){
  const keys=await caches.keys();
  await Promise.all(keys.filter(x=>x!==C&&x.startsWith('english-5000')).map(x=>caches.delete(x)));
  await self.clients.claim();
}
self.addEventListener('install',e=>e.waitUntil(install()));
self.addEventListener('activate',e=>e.waitUntil(activate()));
self.addEventListener('fetch',e=>{
  const r=e.request;
  if(r.method!=='GET'||new URL(r.url).origin!==location.origin)return;
  if(r.mode==='navigate'){e.respondWith(caches.match('index.html').then(h=>h||fetch(r)).catch(()=>fetch(r)));return}
  e.respondWith(caches.match(r,{ignoreSearch:true}).then(h=>h||fetch(r)));
});
