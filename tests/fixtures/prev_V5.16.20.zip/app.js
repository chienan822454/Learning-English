const APP_VERSION='5.16.20';
const HTML_VER=(document.getElementById('appVer')||{}).textContent||'';
try{
  localStorage.removeItem('e5k_sr_once')
}catch(e){}
/* ===== V5.16.14 學習紀錄：安全載入＋每日自動備份 ===== */
const STORE_KEY='english5000v5',SNAP_KEY='english5000v5_snaps',PRE_KEY='english5000v5_before_restore',BACKUP_SCHEMA=3;
function lsGet(k){
  try{
    return localStorage.getItem(k)
  }catch(e){
    return null
  }
}
function lsSet(k,v){
  try{
    localStorage.setItem(k,v);
    return true
  }catch(e){
    return false
  }
}
function snapList(){
  try{
    const a=JSON.parse(lsGet(SNAP_KEY)||'[]');
    return Array.isArray(a)?a.filter(x=>x&&x.progress&&typeof x.progress==='object'):[]
  }catch(e){
    return []
  }
}
function todayStr(){
  const d=new Date();
  return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')
}
function hasProgress(p){
  return !!p&&['fav','known','wordFav','wordKnown','phKnown','phFav','studyDays'].some(k=>Array.isArray(p[k])&&p[k].length)||!!p&&['wordStatus','reviewDue','wrongWords','sDue','pDue'].some(k=>p[k]&&typeof p[k]==='object'&&Object.keys(p[k]).length)
}
/* 每天第一次開啟時保存一份（保留最近 3 天），在任何轉移或修改之前 */
function takeSnapshot(p){
  const t=todayStr();
  if(lsGet(SNAP_KEY+'_date')===t)return;
  if(!hasProgress(p))return;
  let a=snapList();
  if(a.some(x=>x.date===t)){
    lsSet(SNAP_KEY+'_date',t);
    return
  }
  p=JSON.parse(JSON.stringify(p));
  a.unshift({date:t,savedAt:new Date().toISOString(),version:APP_VERSION,progress:p});
  a=a.slice(0,3);
  while(a.length){
    if(lsSet(SNAP_KEY,JSON.stringify(a))){
      lsSet(SNAP_KEY+'_date',t);
      snapMetaSave(a);
      return
    }
    a.pop()
  }
}
function snapMetaSave(a){
  try{
    lsSet(SNAP_KEY+'_meta',JSON.stringify(a.map(x=>({date:x.date,summary:progSummary(x.progress)}))))
  }catch(e){}
}
function snapMeta(){
  try{
    const m=JSON.parse(lsGet(SNAP_KEY+'_meta')||'null');
    if(Array.isArray(m)&&m.every(x=>x&&x.date&&x.summary))return m
  }catch(e){}
  const a=snapList();
  snapMetaSave(a);
  return a.map(x=>({date:x.date,summary:progSummary(x.progress)}))
}
function normStore(s){
  s=(s&&typeof s==='object'&&!Array.isArray(s))?s:{};
  ['fav','known','wordFav','wordKnown'].forEach(k=>{
    if(!Array.isArray(s[k]))s[k]=[]
  });
  ['wordStatus','reviewDue'].forEach(k=>{
    if(!s[k]||typeof s[k]!=='object'||Array.isArray(s[k]))s[k]={}
  });
  if(!s.settings||typeof s.settings!=='object')s.settings={dailyGoal:20};
  return s
}
function dlgSentences(){
  const out=[];
  const W=window.WORDS||[];
  const ce=W.filter(x=>x.k===7&&!x.b).map(x=>[x.w,' '+x.w.toLowerCase()+' ']);
  (window.DIALOGS||[]).forEach(d=>d.lines.forEach((L,n)=>{
    const low=' '+L.en.toLowerCase().replace(/[^a-z0-9-]/g,' ')+' ';
    const keys=ce.filter(c=>low.includes(c[1])).slice(0,2).map(c=>c[0]);
    out.push({id:'d:'+d.id+':'+n,en:L.en,zh:L.zh,keys,src:'dialog',dlg:d.id,who:L.s,kzh:d.t})
  }));
  return out
}
function loadStore(){
  let raw=lsGet(STORE_KEY)||lsGet('english5000v3'),s=null;
  if(raw){
    try{
      s=JSON.parse(raw)
    }catch(e){
      s=null;
      lsSet('english5000v5_corrupt_'+Date.now(),raw);
      const sn=snapList()[0];
      if(sn){
        s=JSON.parse(JSON.stringify(sn.progress));
        window.__storeNote='⚠️ 學習紀錄檔案損毀，已自動改用 '+sn.date+' 的自動備份。'
      }else window.__storeNote='⚠️ 學習紀錄檔案損毀，無法讀取；原始內容已另存，請匯入備份檔。';
      s=normStore(s);
      lsSet(STORE_KEY,JSON.stringify(s))
    }
  }
  s=normStore(s);
  try{
    takeSnapshot(s)
  }catch(e){}
  return s
}
const $=s=>document.querySelector(s), store=loadStore();
store.wordFav=store.wordFav||[];
store.wordKnown=store.wordKnown||[];
store.wordStatus=store.wordStatus||{};
store.reviewDue=store.reviewDue||{};
store.settings=store.settings||{dailyGoal:20};
const ALLS=[...SENTENCES.map(s=>Object.assign({src:'core'},s)),...WORDS.map(x=>({id:'w:'+x.w,en:x.ex,zh:x.exz,keys:[x.w],src:'word',book:x.k})),...PHRASES.map(x=>({id:'p:'+x.id,en:x.ex,zh:x.exz,keys:[x.p],kzh:x.zh,src:'phrase',cat:x.cat})),...dlgSentences()];
const SRC_LABEL={core:'精選',word:'單字例句',phrase:'片語例句',dialog:'對話句'};
function inUnit(s,u){
  if(u==='every')return true;
  if(u==='lsw')return !!(store.lsWrong&&store.lsWrong[s.id]);
  if(u==='dall')return s.src==='dialog';
  if(/^d\d\d$/.test(u))return s.dlg===u;
  if(u==='all')return s.src==='core';
  if(u==='life'||u==='ce')return s.src==='core'&&s.cat===u;
  if(u==='sdue')return isSDue(s.id);
  if(u==='wall')return s.src==='word'&&s.book<=5;
  if(/^w[1-7]$/.test(u))return s.src==='word'&&s.book===+u[1];
  if(u==='pall')return s.src==='phrase';
  if(/^p(daily|work|ce)$/.test(u))return s.src==='phrase'&&s.cat===u.slice(1);
  if(u==='fav')return cset('fav').has(s.id);
  return s.src==='core'
}
let pool=ALLS.filter(s=>s.src==='core'),i=0,slow=false,voices=[],deferred;/* V5.16.16 效能：存檔延後 0.25 秒合併成一次（離開、切到背景、重新載入前一定立刻存）；
   已熟／收藏等清單改用快取查詢，避免每次在數千筆陣列裡逐一比對 */
let STV=0,_svT=0,_svLock=false;
const _cs={};
function saveNow(){
  clearTimeout(_svT);
  _svT=0;
  if(_svLock)return;
  if(!lsSet(STORE_KEY,JSON.stringify(store))&&!window.__quotaWarned){
    window.__quotaWarned=1;
    setTimeout(()=>alert('⚠️ 手機儲存空間不足，學習紀錄無法儲存。請到「統計 › 資料備份」匯出備份檔，並清理瀏覽器空間。'),0)
  }
}
const save=()=>{
  STV++;
  if(!_svT&&!_svLock)_svT=setTimeout(saveNow,250)
};
function saveLock(){
  clearTimeout(_svT);
  _svT=0;
  _svLock=true
}
const flushSave=()=>{
  if(_svT)saveNow()
};
addEventListener('pagehide',flushSave);
addEventListener('beforeunload',flushSave);
document.addEventListener('visibilitychange',()=>{
  if(document.hidden)flushSave()
});
function debounce(f,ms){
  let t;
  return()=>{
    clearTimeout(t);
    t=setTimeout(f,ms)
  }
}
function cset(k){
  const a=store[k]||[];
  const c=_cs[k];
  if(c&&c.v===STV&&c.a===a&&c.n===a.length)return c.s;
  const st=new Set(a);
  _cs[k]={v:STV,a,n:a.length,s:st};
  return st
}
function voiceLoad(){
  voices=speechSynthesis.getVoices().filter(v=>/^en/i.test(v.lang));
  if(window.fillVoices)setTimeout(()=>{
    try{
      fillVoices()
    }catch(e){}
  },0)
}
function pickVoice(){
  let pref=store.settings&&store.settings.voice;
  let v=voices.find(x=>x.voiceURI===pref);
  if(v)return v;
  const us=voices.filter(x=>/en[-_]US/i.test(x.lang));
  const good=/Samantha|Aria|Jenny|Google US English|Ava|Allison|Zira/i;
  return us.find(x=>good.test(x.name))||us[0]||voices[0]
}
speechSynthesis.onvoiceschanged=voiceLoad;
voiceLoad();
let sayTok=0;
function say(t,rate=1,times=1,done){
  speechSynthesis.cancel();
  const tok=++sayTok;
  let n=0;
  function go(){
    if(tok!==sayTok)return;
    const u=new SpeechSynthesisUtterance(t);
    u.lang='en-US';
    u.rate=rate;
    const pv=pickVoice();
    if(pv){
      u.voice=pv;
      u.lang=pv.lang
    }
    u.onend=()=>{
      if(tok!==sayTok)return;
      if(++n<times)setTimeout(go,250);else done&&done()
    };
    speechSynthesis.speak(u)
  }
  go()
}
function cur(){
  return pool[i]||SENTENCES[0]
}
const WMAP={};
WORDS.forEach(x=>WMAP[x.w]=x);
function dispW(w){
  let x=WMAP[w];
  return x&&x.d?x.d:w
}
const KX=window.KEYX||{};
function ipaFor(w){
  let k=w.toLowerCase(),x=WMAP[w]||KX[w]||WMAP[k]||KX[k];
  return x?x.p:''
}
function render(){
  let s=cur();
  if(window.voiceOnRender)window.voiceOnRender(s.id);
  $('#english').textContent=s.en;
  $('#chinese').textContent=s.zh;
  $('#chinese').hidden=true;
  $('#progress').textContent=`${SRC_LABEL[s.src]||'句子'} ${i+1} / ${pool.length}`;
  if(store.settings.pos){
    const uk=$('#unit').value;
    if(store.settings.pos[uk]!==i){
      store.settings.pos[uk]=i;
      save()
    }
  }
  $('#fav').textContent=(store.fav.includes(s.id)?'★':'☆')+' 收藏';
  $('#known').textContent=(store.known.includes(s.id)?'✓ 已會說':'✓ 我會說了');
  $('#sReview').hidden=!isSDue(s.id);
  $('#result').textContent='按下後朗讀上面的英文句子';
  if(window.rpRender)window.rpRender(s);
  $('#keywords').innerHTML=s.keys.map(w=>`<div class="key"><div><strong>${dispW(w)}</strong><span>${ipaFor(w)?'/ '+ipaFor(w)+' /':''}</span><span class="kzh">${esc((WMAP[w]&&WMAP[w].zh)||(KX[w]&&KX[w].pos+' '+KX[w].zh)||s.kzh||'')}</span></div><button data-word="${w}">🔊</button></div>`).join('')
}
function toggle(k){
  let id=cur().id,a=store[k],n=a.indexOf(id);
  n<0?a.push(id):a.splice(n,1);
  if(k==='known'){
    if(n<0)srsSet('s',id,1);else srsDel('s',id)
  }
  save();
  filter();
  render()
}
function filter(){
  let u=$('#unit').value,hk=$('#hideKnown').checked,kn=cset('known');
  pool=u==='search'?searchPool.slice():ALLS.filter(s=>inUnit(s,u)).filter(s=>!(hk&&kn.has(s.id)&&!isSDue(s.id)));
  i=Math.min(i,Math.max(0,pool.length-1));
  if(!pool.length){
    pool=ALLS.filter(s=>s.src==='core');
    i=0
  }
}
$('#play').onclick=()=>say(cur().en,slow?.67:1);
$('#slow').onclick=()=>{
  slow=!slow;
  $('#slow').textContent='🐢 慢速：'+(slow?'開':'關');
  say(cur().en,slow?.67:1)
};
$('#showZh').onclick=()=>$('#chinese').hidden=!$('#chinese').hidden;
$('#repeat').onclick=()=>say(cur().en,slow?.67:1,3);
$('#prev').onclick=()=>{
  if(window.rpNav&&window.rpNav(-1))return;
  i=(i-1+pool.length)%pool.length;
  render()
};
$('#next').onclick=()=>{
  if(window.rpNav&&window.rpNav(1))return;
  i=(i+1)%pool.length;
  render()
};
$('#fav').onclick=()=>toggle('fav');
$('#known').onclick=()=>{
  let was=store.known.includes(cur().id);
  toggle('known');
  markStudy();
  if(!was)bumpLog('sent')
};
store.settings.pos=store.settings.pos||{};
$('#unit').onchange=()=>{
  if(window.rpOff)window.rpOff();
  let u=$('#unit').value;
  if(u!=='search')store.settings.unit=u;
  i=store.settings.pos[u]||0;
  save();
  filter();
  render()
};
/* V5.16.20：重新篩選時盡量停在同一句 */
function refilter(){
  const id=cur().id;
  filter();
  const k=pool.findIndex(s=>s.id===id);
  if(k>=0)i=k
}
$('#hideKnown').onchange=()=>{
  store.settings.hideKnown=$('#hideKnown').checked;
  save();
  refilter();
  render()
};
$('#keywords').onclick=e=>{
  let w=e.target.dataset.word;
  if(w)say(w,.85)
};
$('#result').addEventListener('click',e=>{
  let b=e.target.closest('[data-say]');
  if(b)say(b.dataset.say,.75)
});/* ===== V5.16：語音模組（錄音＋辨識）=====
   每次錄音都是新的 session：重新取得麥克風、新的 MediaRecorder、新的 chunks；
   停止後關閉麥克風、釋放舊的錄音網址；任何失敗都會把按鈕恢復成可再按的狀態。 */
const VOICE={sr:null,srTimer:null,srBusy:false,lastId:null};
const REC={state:'idle',seq:0,stream:null,mr:null,parts:[],type:'',url:null,sid:null,timer:null,guard:null,idle:null,done:0,player:null,maxMs:30000,keepMs:60000,ctx:null,src:null,proc:null,bufs:[],rate:0,mic:'',diag:'',n:0};
/* V5.16.6 錄音：同時用 MediaRecorder 與 Web Audio(WAV) 兩種方式收音，自動採用有聲音的那一個；
   麥克風在錄完後保留 60 秒，連續錄音時沿用，不再每次重新取得（iPhone 重新取得常會變成靜音）。 */
const RAC=window.AudioContext||window.webkitAudioContext;
/* V5.16.7：iPhone 播放聲音後會把網頁切成「只播放」模式，之後麥克風只收到靜音。
   第一次用麥克風起，就把網頁音訊設為「播放＋錄音」模式並保持，播放後仍可收音。 */
function audioSessPR(){
  try{
    if(navigator.audioSession&&navigator.audioSession.type!=='play-and-record')navigator.audioSession.type='play-and-record'
  }catch(e){}
}
function audioSessInfo(){
  try{
    return navigator.audioSession?('音訊模式 '+navigator.audioSession.type+(navigator.audioSession.state?'/'+navigator.audioSession.state:'')):'音訊模式 不支援設定'
  }catch(e){
    return '音訊模式 ?'
  }
}
function micReload(){
  try{
    saveNow();
    sessionStorage.setItem('e5k_rl',String(Date.now()));
    store.settings.pos=store.settings.pos||{};
    const uv=$('#unit').value;
    if(uv&&uv!=='search')store.settings.unit=uv;
    store.settings.pos[uv]=i;
    saveNow();
    sessionStorage.setItem('e5k_go','practice')
  }catch(e){}
  location.reload()
}
function recMsg(t,kind,reload){
  const el=$('#recMsg');
  if(!el)return;
  el.textContent=t||'';
  el.className='rec-msg'+(kind?' '+kind:'');
  el.hidden=!t;
  if(reload){
    const b=document.createElement('button');
    b.className='mini rec-reload';
    b.textContent='🔄 重新啟動麥克風（重新載入，回到同一句）';
    b.onclick=micReload;
    el.appendChild(document.createElement('br'));
    el.appendChild(b)
  }
}
function recUI(st){
  REC.state=st;
  const b=$('#record');
  if(!b)return;
  b.disabled=(st==='starting'||st==='stopping');
  b.textContent={idle:REC.url?'🎙 重新錄音':'🎙 開始錄音',starting:'⏳ 開啟麥克風…',recording:'■ 停止錄音',stopping:'⏳ 處理中…'}[st]||'🎙 開始錄音';
  b.classList.toggle('rec-on',st==='recording');
  const can=!!REC.url&&st==='idle';
  $('#mine').disabled=!can;
  $('#compare').disabled=!can
}
function recNodes(){
  if(REC.proc){
    try{
      REC.proc.onaudioprocess=null;
      REC.proc.disconnect()
    }catch(e){}
  }
  if(REC.src){
    try{
      REC.src.disconnect()
    }catch(e){}
  }
  REC.proc=REC.src=null;
  if(REC.ctx){
    const c=REC.ctx;
    REC.ctx=null;
    try{
      c.close().catch(()=>{})
    }catch(e){}
  }
}
function recRelease(){
  recNodes();
  clearTimeout(REC.timer);
  clearTimeout(REC.guard);
  clearTimeout(REC.idle);
  REC.timer=REC.guard=REC.idle=null;
  if(REC.stream){
    try{
      REC.stream.getTracks().forEach(t=>{
        t.onended=null;
        t.stop()
      })
    }catch(e){}
  }
  REC.stream=null
}
function recKeep(){
  recNodes();
  clearTimeout(REC.timer);
  clearTimeout(REC.guard);
  REC.timer=REC.guard=null;
  clearTimeout(REC.idle);
  REC.idle=setTimeout(()=>{
    if(REC.state==='idle')recRelease()
  },REC.keepMs)
}
function recStopPlayback(){
  try{
    if(REC.player){
      REC.player.pause()
    }
  }catch(e){}
  try{
    if(window.speechSynthesis&&(speechSynthesis.speaking||speechSynthesis.pending))speechSynthesis.cancel()
  }catch(e){}
}
function recErrText(e){
  const n=(e&&e.name)||'';
  if(n==='NotAllowedError'||n==='SecurityError'||n==='PermissionDeniedError')return '🚫 麥克風權限被拒絕。iPhone：設定 › Safari › 麥克風 › 允許（或網址列「aA › 網站設定 › 麥克風」）；Chrome：網址列左側 🔒 › 麥克風 › 允許。改好後再按一次「錄音」。';
  if(n==='NotFoundError'||n==='DevicesNotFoundError')return '🎙 找不到麥克風，請確認手機或耳機麥克風可用。';
  if(n==='NotReadableError'||n==='TrackStartError'||n==='AbortError')return '🎙 麥克風正被其他 App 或通話使用，請關閉後再按一次「錄音」。';
  return '⚠️ 無法開始錄音（'+(n||(e&&e.message)||'未知錯誤')+'），請再按一次「錄音」重試。'
}
function recSupported(){
  if(!window.isSecureContext&&location.hostname!=='localhost')return '⚠️ 錄音需要 https 網址（請用 GitHub Pages 網址開啟）。';
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)return '⚠️ 這個瀏覽器不支援麥克風錄音，請改用 Safari（iPhone）或 Chrome（Android）。';
  if(!RAC&&!window.MediaRecorder)return '⚠️ 這個瀏覽器不支援錄音功能，請更新 iOS／瀏覽器，或改用 Safari／Chrome。';
  return ''
}
function recLive(){
  const s=REC.stream;
  if(!s)return false;
  const t=s.getAudioTracks()[0];
  return !!t&&t.readyState==='live'&&!t.muted&&t.enabled!==false
}
function wavBlob(bufs,rate){
  let n=0;
  bufs.forEach(b=>n+=b.length);
  const out=16000,ratio=rate>out?rate/out:1,len=Math.floor(n/ratio),sr=Math.round(rate/ratio);
  const all=new Float32Array(n);
  let o=0;
  bufs.forEach(b=>{
    all.set(b,o);
    o+=b.length
  });
  const pcm=new Int16Array(len);
  let peak=0;
  for(let k=0;k<len;k++){
    const st=Math.floor(k*ratio),en=Math.min(n,Math.floor((k+1)*ratio));
    let sum=0,c=0;
    for(let j=st;j<en;j++){
      sum+=all[j];
      c++
    }
    let v=c?sum/c:all[st]||0;
    if(Math.abs(v)>peak)peak=Math.abs(v);
    v=Math.max(-1,Math.min(1,v));
    pcm[k]=v<0?v*0x8000:v*0x7fff
  }
  const buf=new ArrayBuffer(44+len*2),dv=new DataView(buf),ws=(p,s)=>{
    for(let k=0;k<s.length;k++)dv.setUint8(p+k,s.charCodeAt(k))
  };
  ws(0,'RIFF');
  dv.setUint32(4,36+len*2,true);
  ws(8,'WAVE');
  ws(12,'fmt ');
  dv.setUint32(16,16,true);
  dv.setUint16(20,1,true);
  dv.setUint16(22,1,true);
  dv.setUint32(24,sr,true);
  dv.setUint32(28,sr*2,true);
  dv.setUint16(32,2,true);
  dv.setUint16(34,16,true);
  ws(36,'data');
  dv.setUint32(40,len*2,true);
  new Int16Array(buf,44).set(pcm);
  return {blob:new Blob([buf],{type:'audio/wav'}),secs:len/sr,peak}
}
async function recStart(){
  if(REC.state!=='idle')return;
  const bad=recSupported();
  if(bad){
    recMsg(bad,'warn');
    return
  }
  srKill();
  recStopPlayback();
  clearTimeout(REC.idle);
  audioSessPR();
  let ctx=null;
  if(RAC){
    try{
      ctx=new RAC();
      if(ctx.resume)ctx.resume().catch(()=>{})
    }catch(e){
      ctx=null
    }
  }
  const my=++REC.seq;
  REC.done=0;
  REC.sid=cur().id;
  recUI('starting');
  recMsg('');
  let stream;
  if(recLive()){
    stream=REC.stream;
    REC.mic='沿用'
  }else{
    if(REC.stream)recRelease();
    try{
      stream=await navigator.mediaDevices.getUserMedia({audio:true})
    }catch(e){
      if(ctx){
        try{
          ctx.close()
        }catch(x){}
      }
      if(my===REC.seq){
        recRelease();
        recUI('idle');
        recMsg(recErrText(e),'warn')
      }
      return
    }
    REC.mic='新取得'
  }
  if(my!==REC.seq||REC.state!=='starting'){
    if(ctx){
      try{
        ctx.close()
      }catch(x){}
    }
    if(REC.stream!==stream)stream.getTracks().forEach(t=>t.stop());
    return
  }
  REC.stream=stream;
  stream.getTracks().forEach(t=>t.onended=()=>{
    if(my===REC.seq&&REC.state==='recording')recStop();else if(REC.stream===stream)REC.stream=null
  });
  let started=0;
  REC.parts=[];
  REC.mr=null;
  REC.bufs=[];
  REC.rate=0;
  REC.ctx=ctx;
  try{
    if(window.MediaRecorder){
      const parts=REC.parts;
      const mt=['audio/mp4','audio/webm;codecs=opus','audio/webm','audio/ogg'].find(t=>MediaRecorder.isTypeSupported&&MediaRecorder.isTypeSupported(t));
      const r=mt?new MediaRecorder(stream,{mimeType:mt}):new MediaRecorder(stream);
      REC.type=r.mimeType||mt||'';
      r.ondataavailable=e=>{
        if(e.data&&e.data.size)parts.push(e.data)
      };
      r.onstop=()=>{
        r.__stopped=true;
        if(my===REC.seq&&REC.state==='stopping')recFinish(my)
      };
      r.onerror=()=>{
        r.__err=true
      };
      REC.mr=r;
      r.start(1000);
      started++
    }
  }catch(e){
    REC.mr=null
  }
  try{
    if(ctx){
      if(ctx.state!=='running'){
        try{
          await ctx.resume()
        }catch(e){}
      }
      if(my!==REC.seq)return;
      const src=ctx.createMediaStreamSource(stream);
      const proc=(ctx.createScriptProcessor||ctx.createJavaScriptNode).call(ctx,4096,1,1);
      const bufs=REC.bufs;
      proc.onaudioprocess=e=>{
        if(my===REC.seq&&REC.state==='recording')bufs.push(new Float32Array(e.inputBuffer.getChannelData(0)))
      };
      src.connect(proc);
      proc.connect(ctx.destination);
      REC.src=src;
      REC.proc=proc;
      REC.rate=ctx.sampleRate;
      started++
    }
  }catch(e){
    recNodes()
  }
  if(!started){
    recFail(my,'⚠️ 無法開始錄音，請再按一次「錄音」重試。');
    return
  }
  recUI('recording');
  recMsg('🔴 錄音中…念完後按「■ 停止錄音」（最長 '+REC.maxMs/1000+' 秒）','on');
  REC.timer=setTimeout(()=>{
    if(my===REC.seq&&REC.state==='recording')recStop()
  },REC.maxMs)
}
function recStop(){
  if(REC.state==='starting'){
    REC.seq++;
    recRelease();
    recUI('idle');
    recMsg('已取消錄音。');
    return
  }
  if(REC.state!=='recording')return;
  const my=REC.seq;
  recUI('stopping');
  clearTimeout(REC.timer);
  const r=REC.mr;
  if(r&&r.state!=='inactive'){
    try{
      r.stop()
    }catch(e){}
    REC.guard=setTimeout(()=>recFinish(my),4000)
  }else{
    REC.guard=setTimeout(()=>recFinish(my),150)
  }
}
function recFinish(my){
  if(my!==REC.seq||REC.done===my)return;
  REC.done=my;
  const bufs=REC.bufs,parts=REC.parts,type=REC.type||(parts[0]&&parts[0].type)||'audio/mp4',hadWav=!!REC.proc||bufs.length>0,hadMr=!!REC.mr,rate=REC.rate;
  REC.bufs=[];
  REC.parts=[];
  REC.mr=null;
  recKeep();
  const w=hadWav&&bufs.length?wavBlob(bufs,rate):null;
  const mb=hadMr?new Blob(parts,{type}):null;
  const wavOk=w&&w.secs>=0.3&&w.peak>=0.004,mrOk=mb&&mb.size>2000;
  let blob=null,use='',warn='';
  if(wavOk){
    blob=w.blob;
    use='WAV'
  }else if(mrOk){
    blob=mb;
    use='MediaRecorder'
  }else if(w&&w.secs>=0.3){
    blob=w.blob;
    use='WAV';
    warn='（聲音非常小，可能沒有收到聲音）'
  }else if(mb&&mb.size>0){
    blob=mb;
    use='MediaRecorder';
    warn='（檔案很小，可能沒有收到聲音）'
  }
  const tk=REC.stream&&REC.stream.getAudioTracks()[0];
  REC.diag='MediaRecorder '+(mb?Math.round(mb.size/1024)+' KB':'無')+'｜WAV '+(w?w.secs.toFixed(1)+' 秒 音量 '+Math.round(w.peak*100)+'%':'無')+'｜採用 '+(use||'無')+'｜麥克風 '+REC.mic+(tk?(tk.muted?' 靜音中':'')+(tk.readyState!=='live'?' 已結束':''):'')+'｜'+audioSessInfo();
  const silent=!wavOk&&!mrOk;
  if(silent){
    recRelease()
  }
  if(!blob){
    recUI('idle');
    recMsg('⚠️ 沒有錄到聲音。手機可能暫時停止提供麥克風聲音，請按下方按鈕重新啟動。\n（診斷：'+REC.diag+'）','warn',true);
    return
  }
  if(REC.url){
    try{
      URL.revokeObjectURL(REC.url)
    }catch(e){}
  }
  REC.url=URL.createObjectURL(blob);
  REC.n++;
  recUI('idle');
  if(silent)recMsg('⚠️ 第 '+REC.n+' 次錄音沒有收到聲音（音量 0%）。手機可能暫時停止提供麥克風聲音，請按下方按鈕重新啟動後再錄。\n（診斷：'+REC.diag+'）','warn',true);else recMsg('✅ 第 '+REC.n+' 次錄好了：按「▶ 我的聲音」或「⇄ 範例→我」；想再錄就按「🎙 重新錄音」。'+warn+'\n（診斷：'+REC.diag+'）',warn?'warn':'ok')
}
function recFail(my,msg){
  if(my!==REC.seq)return;
  REC.done=my;
  try{
    if(REC.mr&&REC.mr.state!=='inactive')REC.mr.stop()
  }catch(e){}
  REC.mr=null;
  recRelease();
  REC.parts=[];
  REC.bufs=[];
  recUI('idle');
  recMsg(msg,'warn')
}
function recDiscard(){
  if(REC.state==='recording'||REC.state==='starting'||REC.state==='stopping'){
    REC.seq++;
    try{
      if(REC.mr&&REC.mr.state!=='inactive')REC.mr.stop()
    }catch(e){}
    REC.mr=null;
    recKeep();
    REC.parts=[];
    REC.bufs=[]
  }
  recStopPlayback();
  if(REC.url){
    try{
      URL.revokeObjectURL(REC.url)
    }catch(e){}
    REC.url=null
  }
  REC.sid=null;
  recUI('idle');
  recMsg('')
}
function recPlay(){
  if(!REC.url||REC.state!=='idle')return;
  if(!REC.player)REC.player=new Audio();
  const p=REC.player;
  try{
    p.pause()
  }catch(e){}
  p.src=REC.url;
  try{
    p.load()
  }catch(e){}
  const pr=p.play();
  if(pr&&pr.catch)pr.catch(()=>recMsg('⚠️ 無法播放錄音，請確認手機不是靜音模式，或再錄一次。','warn'))
}
$('#record').onclick=()=>{
  if(REC.state==='recording'||REC.state==='starting')recStop();else recStart()
};
$('#mine').onclick=()=>{
  recStopPlayback();
  recPlay()
};
$('#compare').onclick=()=>{
  if(!REC.url||REC.state!=='idle')return;
  recStopPlayback();
  say(cur().en,1,1,()=>recPlay())
};
document.addEventListener('visibilitychange',()=>{
  if(document.hidden){
    if(REC.state==='recording'||REC.state==='starting')recStop();else if(REC.state==='idle')recRelease();
    srKill()
  }
});
/* 跟讀辨識：每次新建 SpeechRecognition；再按一次停止；10 秒自動停止；結束後按鈕一定恢復 */
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
function srBtn(on){
  const b=$('#check');
  if(b){
    b.textContent=on?'■ 停止聆聽':'🎤 開始念，幫我檢查';
    b.classList.toggle('rec-on',on)
  }
}
function srErrText(c){
  return({'not-allowed':'🚫 麥克風或語音辨識權限被拒絕。iPhone 需開啟：設定 › 一般 › 鍵盤 › 啟用聽寫，並允許 Safari 使用麥克風。','service-not-allowed':'🚫 語音辨識服務未開啟。iPhone：設定 › 一般 › 鍵盤 › 啟用聽寫。','no-speech':'🤔 沒有聽到聲音，請靠近麥克風再按一次。','audio-capture':'🎙 找不到麥克風，或麥克風正被其他 App 使用。','network':'📶 語音辨識需要網路，請確認連線後再試。','aborted':'已停止聆聽。'})[c]||('無法辨識：'+c+'，請再按一次重試。')
}
/* V5.16.19：🎤 評分 — 數字、時間、縮寫、連字號名稱都能對上（例：2:15 ↔ two fifteen、What's ↔ what is、UPS-2A ↔ UPS 2 A） */
const SC_NUM=Object.assign(Object.create(null),{zero:0,oh:0,one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10,eleven:11,twelve:12,thirteen:13,fourteen:14,fifteen:15,sixteen:16,seventeen:17,eighteen:18,nineteen:19,twenty:20,thirty:30,forty:40,fifty:50,sixty:60,seventy:70,eighty:80,ninety:90});
const SC_CON=Object.assign(Object.create(null),{"what's":"what is","that's":"that is","it's":"it is","there's":"there is","here's":"here is","where's":"where is","who's":"who is","how's":"how is","he's":"he is","she's":"she is","let's":"let us","i'm":"i am","you're":"you are","we're":"we are","they're":"they are","i'll":"i will","you'll":"you will","we'll":"we will","they'll":"they will","it'll":"it will","that'll":"that will","i've":"i have","you've":"you have","we've":"we have","they've":"they have","i'd":"i would","you'd":"you would","we'd":"we would","don't":"do not","doesn't":"does not","didn't":"did not","can't":"can not","won't":"will not","isn't":"is not","aren't":"are not","wasn't":"was not","weren't":"were not","haven't":"have not","hasn't":"has not","hadn't":"had not","shouldn't":"should not","couldn't":"could not","wouldn't":"would not","mustn't":"must not","cannot":"can not","okay":"ok"});
function scTok(text){
  let t=String(text||'').toLowerCase().replace(/[’‘`]/g,"'");
  t=t.replace(/\b([ap])\.\s?m\b\.?/g,' $1m ').replace(/\bo\.k\.?/g,' ok ');
  t=t.replace(/[a-z]+'[a-z]+/g,w=>SC_CON[w]||w.replace(/'/g,''));
  let raw=t.replace(/[^a-z0-9]+/g,' ').split(' ').filter(Boolean),out=[];
  raw.forEach(w=>{
    const c=SC_CON[w];
    if(c){
      out.push(...c.split(' '));
      return
    }
    if(w==='hundred'){
      out.push('hundred');
      return
    }
    if(w in SC_NUM){
      out.push(String(SC_NUM[w]));
      return
    }
    out.push(/^\d+$/.test(w)?String(parseInt(w,10)):w)
  });
  const t1=[];
  for(let k=0;k<out.length;k++){
    const a=out[k],b=out[k+1];
    if(/^\d+$/.test(a)&&+a>=20&&+a<=90&&+a%10===0&&b&&/^[1-9]$/.test(b)){
      t1.push(String(+a+ +b));
      k++
    }else t1.push(a)
  }
  const m=[];
  for(let k=0;k<t1.length;k++){
    const a=t1[k],b=t1[k+1];
    if(a==='hundred'&&m.length&&/^\d$/.test(m[m.length-1])){
      let v=+m.pop()*100;
      if(b&&/^\d+$/.test(b)&&+b<100){
        v+=+b;
        k++
      }
      m.push(String(v))
    }else m.push(a)
  }
  return m
}
function scHeard(text){
  const toks=scTok(text);
  const H=new Set(toks);
  const nz=x=>/^\d+$/.test(x)?String(parseInt(x,10)):x;
  for(let k=0;k+1<toks.length;k++)H.add(nz(toks[k]+toks[k+1]));
  for(let k=0;k<toks.length;k++){
    if(toks[k].length!==1)continue;
    let j=k,s='';
    while(j<toks.length&&toks[j].length===1){
      s+=toks[j];
      j++
    }
    if(j-k>=2)H.add(nz(s));
    k=j-1
  }
  toks.forEach(x=>{
    if(/^\d{3,4}$/.test(x)){
      H.add(x.slice(0,-2).replace(/^0+(?=\d)/,''));
      H.add(String(+x.slice(-2)))
    }
  });
  return H
}
function scMatch(want,H){
  return want.filter(x=>H.has(x)).length
}
function srResult(heard){
  const a=scTok(cur().en),H=scHeard(heard),hit=scMatch(a,H),score=a.length?Math.round(hit/a.length*100):0;
  let toks=cur().en.split(/\s+/),miss=[];
  let marked=toks.map(t=>{
    let c=t.toLowerCase().replace(/[^a-z0-9 ]/g,'');
    if(!c)return esc(t);
    const sub=scTok(t);
    let ok=sub.every(p=>H.has(p));
    if(!ok)miss.push(t.replace(/^[^A-Za-z0-9]+|[^A-Za-z0-9.]+$/g,'').replace(/\.$/,''));
    return `<span class="${ok?'sw-ok':'sw-miss'}">${esc(t)}</span>`
  }).join(' ');
  $('#result').innerHTML=`<div class="sw-line">${marked}</div><b>相似度 ${score}%</b>${miss.length?`<br><small>紅色是漏掉或沒聽清楚的字：${esc(miss.join('、'))}</small><div class="sw-btns">${miss.slice(0,4).map(m=>`<button data-say="${esc(m)}">🔊 ${esc(m)}</button>`).join('')}</div>`:'<br><small>👍 全部都有念到！</small>'}<br><small class="muted">辨識到：${esc(heard)}</small>`;
  if(window.rpScore)window.rpScore(score);
  if(score>=90)bumpLog('shadow')
}
/* V5.16.5：iPhone 語音辨識常常只有第一次有效。改為「沿用同一個辨識器」與「重新建立」兩種方式輪替：
   某種方式聽不到時，下一次自動換另一種；並顯示診斷事件，方便回報。 */
/* V5.16.8：iPhone 語音辨識每次載入網頁通常只能啟動一次。改為「背景持續辨識」：
   第一次按 🎤 啟動一個連續辨識，之後每次按 🎤 只擷取按下後聽到的內容，不重新啟動辨識器。
   若手機仍結束了背景辨識、新的又聽不到，就顯示「重新啟動麥克風」。 */
VOICE.n=0;
VOICE.sess=null;
VOICE.att=null;
VOICE.trace=[];
VOICE.sessN=0;
function srT(n){
  VOICE.trace.push(n+' '+((Date.now()-VOICE.t0)/1000).toFixed(1)+'s')
}
function srEv(n){
  if(VOICE.att)srT(n)
}
const SR_RELOAD='<br><button class="mini rec-reload" onclick="micReload()">🔄 重新啟動麥克風（重新載入，回到同一句）</button>';
function srDiag(a){
  const dur=(Date.now()-VOICE.t0)/1000;
  const deaf=!a.got&&dur>=2.5;
  return '<br><small class="muted">診斷：'+esc(VOICE.trace.join('、')||'沒有任何事件')+'｜背景辨識 #'+(a.sess?a.sess.__no:'-')+'（'+a.how+'）｜第 '+a.n+' 次｜'+esc(audioSessInfo())+(srJustReloaded()?'｜剛重新載入':'')+'</small>'+(deaf?(srJustReloaded()&&!VOICE.heard?SR_STUCK:'<br><small>麥克風有開啟但沒有辨識到內容。如果你有念出聲音，請按下方按鈕重新啟動。</small>'+SR_RELOAD):'')
}
function srAbort(){
  clearTimeout(VOICE.srTimer);
  clearTimeout(VOICE.srGuard);
  VOICE.att=null;
  if(VOICE.srBusy){
    VOICE.srBusy=false;
    srBtn(false)
  }
}
function srKill(){
  srAbort();
  clearTimeout(VOICE.idleT);
  const s=VOICE.sess;
  VOICE.sess=null;
  if(s){
    s.__dead=true;
    try{
      s.abort()
    }catch(e){}
  }
}
function srJustReloaded(){
  try{
    const t=+sessionStorage.getItem('e5k_rl')||0;
    return Date.now()-t<5*60*1000
  }catch(e){
    return false
  }
}
const SR_STUCK='<br><b>⚠️ 重新載入後語音辨識仍然聽不到，這是瀏覽器本身的辨識功能暫時卡住，重新載入網頁無法修復。</b><br><small>請試：① 從 iPhone 多工畫面把 Edge 完全滑掉再重開；② 或改用 Safari 開啟（實測 Safari 可連續使用）。「🎙 錄音」與「⇄ 範例→我」不受影響，可以先用錄音對比發音。</small>';
function srOnce(){
  try{
    return sessionStorage.getItem('e5k_sr_once')==='1'
  }catch(e){
    return false
  }
}
function srReload(){
  $('#result').textContent='🔄 這支手機每次載入網頁只能啟動一次語音辨識，正在重新啟動麥克風（約 1 秒，回到同一句）…';
  try{
    sessionStorage.setItem('e5k_sr','1')
  }catch(e){}
  setTimeout(micReload,300)
}
/* V5.16.10：整句的字都聽到了就立刻評分，不必等手機確認（約快 3 秒） */
function srNorm(x){
  return String(x||'').toLowerCase().replace(/[’‘`]/g,"'").replace(/[^a-z0-9' ]/g,' ').replace(/\s+/g,' ').trim()
}
function srAll(t){
  const want=scTok(cur().en),H=scHeard(t);
  return want.length>0&&want.every(w=>H.has(w))
}
function srSession(){
  const r=new SR();
  r.lang='en-US';
  r.continuous=true;
  r.interimResults=true;
  r.maxAlternatives=1;
  VOICE.sessN++;
  r.__no=VOICE.sessN;
  r.__len=0;
  r.__alive=false;
  r.__dead=false;
  r.onstart=()=>{
    r.__alive=true;
    srEv('start')
  };
  r.onaudiostart=()=>{
    r.__alive=true;
    srEv('audio')
  };
  r.onsoundstart=()=>srEv('sound');
  r.onspeechstart=()=>srEv('speech');
  r.onresult=e=>{
    r.__alive=true;
    r.__len=e.results.length;
    r.__heardSince=true;
    let full='';
    for(let k=0;k<e.results.length;k++)full+=e.results[k][0].transcript+' ';
    full=srNorm(full);
    r.__full=full;
    const a=VOICE.att;
    if(!a||a.sess!==r)return;
    let t='',fin=false;
    if(full.startsWith(a.base)){
      t=full.slice(a.base.length).trim();
      fin=!!(e.results.length&&e.results[e.results.length-1].isFinal)
    }else{
      for(let k=a.from;k<e.results.length;k++){
        t+=e.results[k][0].transcript+' ';
        if(e.results[k].isFinal)fin=true
      }
      t=srNorm(t)
    }
    if(!t)return;
    if(!a.got)srT('result');
    a.got=t;
    if(fin||srAll(t)){
      if(!fin)srT('all-words');
      srDone(a)
    }else $('#result').innerHTML='🎧 聽到：<i>'+esc(t)+'</i>'
  };
  r.onerror=e=>{
    srEv('error:'+e.error);
    const a=VOICE.att;
    if(a&&a.sess===r&&/not-allowed|service-not-allowed|audio-capture|network/.test(e.error))srDone(a,srErrText(e.error))
  };
  r.onend=()=>{
    srEv('end');
    r.__dead=true;
    if(VOICE.sess===r)VOICE.sess=null;
    const a=VOICE.att;
    if(a&&a.sess===r)srDone(a)
  };
  return r
}
function srDone(a,why){
  if(VOICE.att!==a)return;
  srT('finish');
  clearTimeout(VOICE.srTimer);
  clearTimeout(VOICE.srGuard);
  VOICE.att=null;
  VOICE.srBusy=false;
  srBtn(false);
  if(a.got){
    if(a.sess)a.sess.__heard=true;
    VOICE.heard=true
  }else if((Date.now()-VOICE.t0)/1000>=2.5&&a.sess){
    if((a.how==='沿用'&&!a.sess.__heardSince)||!a.sess.__heard){
      a.sess.__dead=true;
      try{
        a.sess.abort()
      }catch(e){}
      if(VOICE.sess===a.sess)VOICE.sess=null
    }
    if(a.sess.__no>=2&&!a.sess.__heard){
      try{
        sessionStorage.setItem('e5k_sr_once','1')
      }catch(e){}
    }
  }
  if(a.got){
    srResult(a.got);
    $('#result').insertAdjacentHTML('beforeend',srDiag(a));
    return
  }
  $('#result').innerHTML=esc(why||'🤔 這次沒有辨識到內容，請再按一次「🎤 開始念」。')+srDiag(a)
}
if(SR){
  $('#check').onclick=()=>{
    if(VOICE.srBusy){
      const a=VOICE.att;
      if(!a){
        srAbort();
        return
      }
      srT('user-stop');
      clearTimeout(VOICE.srTimer);
      clearTimeout(VOICE.srGuard);
      VOICE.srGuard=setTimeout(()=>srDone(a,a.got?'':'已停止聆聽。（念完後請稍等 1～2 秒再按停止，或直接等它自動評分）'),1500);
      return
    }
    if(REC.state==='recording'||REC.state==='starting')recStop();
    recStopPlayback();
    if(REC.state==='idle')recRelease();
    audioSessPR();
    VOICE.n++;
    VOICE.t0=Date.now();
    VOICE.trace=[];
    let s=VOICE.sess,how='沿用';
    if((!s||s.__dead)&&VOICE.sessN>=1&&srOnce()&&!(srJustReloaded()&&!VOICE.heard)){
      srReload();
      return
    }
    if(!s||s.__dead){
      how='新開';
      try{
        s=srSession()
      }catch(e){
        $('#result').textContent='⚠️ 無法啟動語音辨識，請重新整理後再試。';
        return
      }
      VOICE.sess=s
    }
    s.__heardSince=false;
    const a={sess:s,from:s.__len,base:s.__full||'',got:'',how,n:VOICE.n};
    VOICE.att=a;
    VOICE.srBusy=true;
    srBtn(true);
    $('#result').textContent='🎧 正在聆聽…請念出上面的句子（念完會自動評分）';
    if(how==='新開'){
      try{
        s.start()
      }catch(e){
        srT('start-fail:'+(e.name||e.message));
        s.__dead=true;
        VOICE.sess=null;
        srDone(a,'⚠️ 語音辨識啟動失敗（'+(e.name||e.message)+'），請再按一次。');
        return
      }
      VOICE.srGuard=setTimeout(()=>{
        if(VOICE.att===a&&!s.__alive){
          s.__dead=true;
          try{
            s.abort()
          }catch(e){}
          if(VOICE.sess===s)VOICE.sess=null;
          srDone(a,'⚠️ 語音辨識沒有回應，已自動重設。請再按一次「🎤 開始念」，或按下方按鈕重新啟動麥克風。')
        }
      },5000)
    }
 else srT('standby');
    VOICE.srTimer=setTimeout(()=>{
      if(VOICE.att===a){
        srT('10s');
        srDone(a)
      }
    },10000);
    clearTimeout(VOICE.idleT);
    VOICE.idleT=setTimeout(()=>{
      if(!VOICE.srBusy)srKill()
    },180000)
  }
}
else{
  $('#check').onclick=()=>{
    $('#result').textContent='⚠️ 此瀏覽器不支援語音辨識，建議使用 Safari、Chrome 或 Edge。錄音對比功能仍可使用。'
  }
}
window.voiceOnRender=id=>{
  if(REC.sid&&REC.sid!==id)recDiscard();
  if(VOICE.srBusy&&VOICE.lastId&&VOICE.lastId!==id)srAbort();
  if(VOICE.lastId!==id)sayTok++;
  VOICE.lastId=id
};
function page(name){
  if(name!=='practice'&&window.rpOff)window.rpOff();
  const pr=name==='practice';
  $('.panel').hidden=!pr;
  $('.sentence').hidden=!pr;
  $('.topline').hidden=!pr;
  $('.tip').hidden=!pr;
  $('#sentenceList').hidden=name!=='list';
  $('#wordPage').hidden=name!=='words';
  $('#quiz').hidden=name!=='quiz';
  $('#phrasePage').hidden=name!=='phrases';
  $('#statsPage').hidden=name!=='stats';
  $('#todayPage').hidden=name!=='today';
  $('#dialogPage').hidden=name!=='dialogs';
  if(name!=='dialogs'&&typeof dlgStop==='function'&&(DLG.run||DLG.playing>=0))dlgStop();
  document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
  let nb=$('#nav'+(name==='list'?'Practice':name[0].toUpperCase()+name.slice(1)));
  if(nb)nb.classList.add('active');
  if(pr&&window.rpAfterPage)window.rpAfterPage();
  window.scrollTo(0,0)
}
$('#navPractice').onclick=()=>{
  page('practice');
  refilter();
  render()
};
$('#navWords').onclick=()=>{
  page('words');
  wordShown=60;
  renderWords()
};
$('#openList').onclick=()=>{
  page('list');
  list()
};
$('#navQuiz').onclick=()=>{
  page('quiz');
  quiz()
};
$('#back1').onclick=$('#back2').onclick=()=>{
  page('practice');
  refilter();
  render()
};
let listRes=[],searchPool=[];
function list(){
  let q=$('#search').value.trim().toLowerCase();
  listRes=(q?ALLS.filter(s=>s.en.toLowerCase().includes(q)||s.zh.includes(q)):pool).slice(0,150);
  $('#rows').innerHTML=(q?'':'<p class="muted">目前分類的句子（最多顯示 150 句）。輸入關鍵字可搜尋全部 '+ALLS.length+' 句。</p>')+listRes.map((s,k)=>`<div class="row" data-k="${k}"><b>${esc(s.en)}</b><small>${esc(s.zh)}　·　${SRC_LABEL[s.src]}${store.known.includes(s.id)?'　✓':''}</small></div>`).join('')
}
$('#rows').onclick=e=>{
  let r=e.target.closest('.row');
  if(!r)return;
  let s=listRes[+r.dataset.k],k=pool.indexOf(s);
  if(k<0){
    searchPool=listRes.slice();
    let o=$('#unit').querySelector('option[value=search]');
    if(!o){
      o=document.createElement('option');
      o.value='search';
      $('#unit').prepend(o)
    }
    o.textContent='🔎 搜尋結果（'+searchPool.length+'）';
    $('#unit').value='search';
    filter();
    k=pool.indexOf(s);
    if(k<0)k=0
  }
  i=k;
  page('practice');
  render()
};
$('#search').oninput=debounce(list,150);
function quiz(){
  const SQ=pool.length>=4?pool:ALLS;
  let s=SQ[Math.floor(Math.random()*SQ.length)],opts=[s,...SQ.filter(x=>x.id!==s.id).sort(()=>Math.random()-.5).slice(0,3)].sort(()=>Math.random()-.5);
  $('#quizQ').textContent=s.en;
  $('#quizOpts').innerHTML=opts.map(x=>`<button data-ok="${x.id===s.id}">${esc(x.zh)}</button>`).join('');
  $('#quizMsg').textContent='';
  let done=false;
  $('#quizOpts').onclick=e=>{
    if(e.target.tagName==='BUTTON'&&!done){
      done=true;
      let ok=e.target.dataset.ok==='true';
      e.target.classList.add(ok?'opt-ok':'opt-bad');
      if(!ok){
        const c=$('#quizOpts').querySelector('[data-ok=true]');
        if(c)c.classList.add('opt-ok')
      }
      $('#quizMsg').textContent=ok?'✅ 答對了！':'❌ 正確答案是綠色那一個';
      store[ok?'quizRight':'quizWrong']=(store[ok?'quizRight':'quizWrong']||0)+1;
      bumpLog('quiz');
      markStudy();
      save()
    }
  }
}
$('#newQuiz').onclick=quiz;
/* ===== V5.1 5000 單字模組（以單字為鍵，避免字庫調整後進度錯位） ===== */
(function migrate(){
  if(store.wordKeyVersion>=2)return;
  const mapR=r=>(window.V4_WORDS||[])[r-1];
  const conv=a=>(a||[]).map(x=>typeof x==='number'?mapR(x):x).filter(Boolean);
  store.wordFav=conv(store.wordFav);
  store.wordKnown=conv(store.wordKnown);
  const st={},due={};
  Object.keys(store.wordStatus||{}).forEach(k=>{
    const w=/^\d+$/.test(k)?mapR(+k):k;
    if(w)st[w]=store.wordStatus[k]
  });
  Object.keys(store.reviewDue||{}).forEach(k=>{
    const w=/^\d+$/.test(k)?mapR(+k):k;
    if(w)due[w]=store.reviewDue[k]
  });
  store.wordStatus=st;
  store.reviewDue=due;
  store.wordKeyVersion=2;
  save()
})();
/* V5.16.12：字庫 QA 後，詞形（went、colour、don't…）併入原形；把舊紀錄轉移到原形。
   已熟不降級、收藏保留、取最早的複習日期、答錯次數相加；轉移前的紀錄另存在 migBackupV3。 */
(function migrateV3(){
  if(store.wordKeyVersion>=3)return;
  const MG=window.MERGED||{};
  const RK={new:0,learning:1,review:2,known:3};
  store.reviewStage=store.reviewStage||{};
  store.wrongWords=store.wrongWords||{};
  const snap={wordFav:store.wordFav,wordKnown:store.wordKnown,wordStatus:store.wordStatus,reviewDue:store.reviewDue,reviewStage:store.reviewStage,wrongWords:store.wrongWords};
  let moved=0;
  const touched=Object.keys(MG).some(o=>store.wordFav.includes(o)||store.wordKnown.includes(o)||store.wordStatus[o]||store.reviewDue[o]||store.reviewStage[o]||store.wrongWords[o]);
  if(touched)store.migBackupV3=JSON.parse(JSON.stringify(snap));
  Object.keys(MG).forEach(o=>{
    const n=MG[o];
    if(!n||n===o)return;
    let hit=false;
    const fi=store.wordFav.indexOf(o);
    if(fi>=0){
      store.wordFav.splice(fi,1);
      if(!store.wordFav.includes(n))store.wordFav.push(n);
      hit=true
    }
    const oldKnown=store.wordKnown.includes(o)||store.wordStatus[o]==='known';
    const ki=store.wordKnown.indexOf(o);
    if(ki>=0){
      store.wordKnown.splice(ki,1);
      hit=true
    }
    const so=store.wordStatus[o];
    if(so){
      const sn=store.wordStatus[n];
      if(!sn||(RK[so]||0)>(RK[sn]||0))store.wordStatus[n]=so;
      delete store.wordStatus[o];
      hit=true
    }
    if(oldKnown){
      store.wordStatus[n]='known';
      if(!store.wordKnown.includes(n))store.wordKnown.push(n)
    }
    const dO=store.reviewDue[o];
    if(dO){
      const dN=store.reviewDue[n];
      store.reviewDue[n]=dN&&dN<dO?dN:dO;
      delete store.reviewDue[o];
      hit=true
    }
    const sg=store.reviewStage[o];
    if(sg!=null){
      store.reviewStage[n]=Math.max(store.reviewStage[n]||0,sg);
      delete store.reviewStage[o];
      hit=true
    }
    const ww=store.wrongWords[o];
    if(ww){
      store.wrongWords[n]=(store.wrongWords[n]||0)+ww;
      delete store.wrongWords[o];
      hit=true
    }
    if(hit)moved++
  });
  store.wordKeyVersion=3;
  store.migratedV3=moved;
  save()
})();
const BY_WORD={};
WORDS.forEach(x=>BY_WORD[x.w]=x);
const _dayC={t:0,v:{}};
function day(n=0){
  const now=Date.now();
  if(now-_dayC.t>30000){
    _dayC.t=now;
    _dayC.v={}
  }
  const c=_dayC.v[n];
  if(c)return c;
  let d=new Date();
  d.setDate(d.getDate()+n);
  return _dayC.v[n]=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')
}
function statusOf(w){
  if(store.wordStatus[w])return store.wordStatus[w];
  if(cset('wordKnown').has(w))return 'known';
  return 'new'
}
function isDue(w){
  return !!store.reviewDue[w]&&store.reviewDue[w]<=day()
}
/* V5.16.13：例句用的是詞形（例如 sprained、buried）時也要標出，避免例句填空直接露出答案 */
function hlForms(w){
  const v=(typeof VS!=='undefined'&&VS[w])||[],l=w.slice(-1),c=w.slice(0,-1);
  return [w,...v,w+'s',w+'es',w+'ed',w+'d',w+'ing',c+'ing',c+'ied',c+'ies',w+l+'ed',w+l+'ing',w+'er',w+'est'].filter((t,k,a)=>t&&a.indexOf(t)===k).sort((a,b)=>b.length-a.length)
}
const _hlC=new Map();
function hl(x){
  if(!x.ex)return '';
  const k=x.w+'\u0001'+x.ex;
  const c=_hlC.get(k);
  if(c!==undefined)return c;
  const r=hl0(x);
  _hlC.set(k,r);
  return r
}
function hl0(x){
  const e=esc(x.ex);
  const fs=hlForms(x.w).map(f=>f.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'));
  const r=new RegExp('(^|[^A-Za-z\'])('+fs.join('|')+')(?![A-Za-z])','i');
  return r.test(e)?e.replace(r,'$1<mark>$2</mark>'):e
}
const ST_LABEL={new:'新字',learning:'學習中',review:'待複習',known:'已熟'};
const esc=s=>String(s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const INTERVALS=[1,3,7,14,30];
function setStatus(w,s,nolog){
  store.reviewStage=store.reviewStage||{};
  let st=store.reviewStage[w]||0;
  let prev=statusOf(w),wasDue=isDue(w);
  if(!nolog){
    if(prev==='new'&&!store.wordStatus[w])bumpLog('new');else if(wasDue)bumpLog('review')
  }
  store.wordStatus[w]=s;
  store.wordKnown=store.wordKnown.filter(x=>x!==w);
  if(s==='known'){
    store.wordKnown.push(w);
    st=Math.min(st+1,INTERVALS.length-1);
    store.reviewDue[w]=day(INTERVALS[st])
  }else if(s==='learning'){
    st=0;
    store.reviewDue[w]=day(INTERVALS[0])
  }else{
    st=0;
    store.reviewDue[w]=day()
  }
  store.reviewStage[w]=st;
  markStudy();
  save()
}
function toggleFav(w){
  let a=store.wordFav,n=a.indexOf(w);
  n<0?a.push(w):a.splice(n,1);
  save()
}
let wordShown=60,cardIndex=0,cardPool=[],cardReveal=false;
function inBook(x,book){
  return book==='all'?!x.ce:x.k==+book
}
function skipV(){
  return store.settings.skipVar!==false
}
function wordFiltered(){
  let q=$('#wordSearch').value.trim().toLowerCase(),book=$('#wordBook').value,st=$('#wordState').value,tp=$('#wordTopic').value;
  return WORDS.filter(x=>(!q||x.w.toLowerCase().includes(q)||(x.zh&&x.zh.includes(q)))&&(q||!skipV()||!x.b)&&(tp==='all'||(x.t||[]).includes(tp))&&((q&&book==='all')||inBook(x,book))&&(st==='all'||(st==='fav'&&cset('wordFav').has(x.w))||(st==='review'&&isDue(x.w))||(st==='wrong'&&!!(store.wrongWords||{})[x.w])||(st==='zh'&&x.zh)||(st!=='fav'&&st!=='review'&&st!=='zh'&&st!=='wrong'&&statusOf(x.w)===st)))
}
function wordStats(n){
  $('#wordCount').textContent=n;
  $('#wordKnownN').textContent=store.wordKnown.length;
  $('#wordFavN').textContent=store.wordFav.length;
  let due=WORDS.filter(x=>isDue(x.w)).length;
  $('#wordDueN').textContent=due
}
function renderWords(){
  if(cardAuto)stopAuto();
  let a=wordFiltered();
  $('#wordRows').hidden=false;
  $('#wordCard').hidden=true;
  wordStats(a.length);
  $('#wordRows').innerHTML=a.slice(0,wordShown).map(x=>`<div class="word-card status-${statusOf(x.w)}" data-w="${esc(x.w)}"><span class="word-rank">${x.ce?'CE':'#'+x.r}</span><span class="word-main"><strong>${esc(dispW(x.w))}</strong> <em class="pos">${esc(x.pos||'')}</em><small>${x.p?'/ '+esc(x.p)+' /':''}</small><span class="zh">${x.zh?esc(x.zh):'<i>中文待補（下一批）</i>'}</span>${relHtml(x)}${x.ex?`<span class="ex">${hl(x)}<br><small>${esc(x.exz)}</small></span>`:''}</span><span class="word-actions"><button data-act="play">🔊</button><button data-act="slow">🐢</button>${x.ex?'<button data-act="ex">💬</button>':''}<button data-act="fav">${cset('wordFav').has(x.w)?'★':'☆'}</button><button data-act="known">${statusOf(x.w)==='known'?'✓':'○'}</button></span></div>`).join('');
  $('#wordMore').hidden=wordShown>=a.length
}
function showCard(){
  let x=cardPool[cardIndex];
  if(!x){
    $('#wordCard').innerHTML='<b>目前沒有符合條件的單字 🎉</b><div class="card-actions"><button data-ca="list">返回列表</button></div>';
    return
  }
  let s=statusOf(x.w);
  $('#wordCard').innerHTML=`<div class="meta">${cardIndex+1} / ${cardPool.length} · ${bookName(x)} · ${ST_LABEL[s]}${store.reviewDue[x.w]?' · 下次複習 '+store.reviewDue[x.w].slice(5):''}</div><div class="big">${esc(dispW(x.w))}</div><div class="phon">${x.p?'/ '+esc(x.p)+' /':''} <em class="pos">${esc(x.pos||'')}</em></div>${relHtml(x)}<div class="reveal">${cardReveal?(x.zh?esc(x.zh):'<i>中文待補</i>'):'<button data-ca="reveal">👁 先想意思，再點我看中文</button>'}</div>${x.ex?`<div class="card-ex"><div class="en">${hl(x)}</div>${cardReveal?`<div class="zhx">${esc(x.exz)}</div>`:''}<div class="exbtn"><button data-ca="ex">💬 例句</button><button data-ca="exslow">🐢 慢速例句</button></div></div>`:''}<div class="card-actions"><button data-ca="play">🔊 正常</button><button data-ca="slow">🐢 慢速</button><button data-ca="fav">${store.wordFav.includes(x.w)?'★ 已收藏':'☆ 收藏'}</button></div><div class="card-actions grade"><button data-ca="g-new" class="g1">✗ 不熟</button><button data-ca="g-learning" class="g2">◐ 模糊</button><button data-ca="g-known" class="g3">✓ 已熟</button></div><div class="card-actions"><button data-ca="auto" class="${cardAuto?'primary':''}">${cardAuto?'⏸ 停止自動':'▶ 自動播放'}</button></div><div class="card-actions"><button data-ca="prev">← 上一字</button><button data-ca="list">列表</button><button data-ca="next">下一字 →</button></div>`;
  if(!cardAuto)say(x.w,1)
}
function openCards(a){
  stopAuto();
  cardPool=a;
  cardIndex=0;
  cardReveal=false;
  $('#wordRows').hidden=true;
  $('#wordMore').hidden=true;
  $('#wordCard').hidden=false;
  showCard();
  window.scrollTo({top:0,behavior:'smooth'})
}
['wordSearch','wordBook','wordState','wordTopic'].forEach(id=>$('#'+id).addEventListener(id==='wordSearch'?'input':'change',id==='wordSearch'?debounce(()=>{
  wordShown=60;
  renderWords()
},150):()=>{
  wordShown=60;
  renderWords()
}));
$('#wordMore').onclick=()=>{
  wordShown+=100;
  renderWords()
};
$('#wordRows').onclick=e=>{
  let jp=e.target.closest('[data-jump]');
  if(jp){
    openCards([BY_WORD[jp.dataset.jump]]);
    return
  }
  let b=e.target.closest('button'),row=e.target.closest('.word-card');
  if(!row)return;
  let w=row.dataset.w;
  if(!b){
    openCards([BY_WORD[w]]);
    return
  }
  let a=b.dataset.act;
  if(a==='play')say(w,1);
  if(a==='slow')say(w,.62);
  if(a==='ex')say(BY_WORD[w].ex,.9);
  if(a==='fav'){
    toggleFav(w);
    renderWords()
  }
  if(a==='known'){
    setStatus(w,statusOf(w)==='known'?'learning':'known');
    renderWords()
  }
};
$('#cardMode').onclick=()=>openCards(wordFiltered());
/* V5.16.20：每日新字目標從紀錄還原（原本重新開啟後會變回 20） */
$('#dailyGoal').value=String([10,20,30,50].includes(+store.settings.dailyGoal)?+store.settings.dailyGoal:20);
$('#dailyGoal').onchange=()=>{
  store.settings.dailyGoal=+$('#dailyGoal').value||20;
  save()
};
$('#dailyStart').onclick=()=>{
  let g=+$('#dailyGoal').value||20;
  store.settings.dailyGoal=g;
  save();
  let book=$('#wordBook').value;
  openCards(WORDS.filter(x=>statusOf(x.w)==='new'&&inBook(x,book)&&!(skipV()&&x.b)).slice(0,g))
};
$('#reviewStart').onclick=()=>openCards(WORDS.filter(x=>isDue(x.w)).sort(()=>Math.random()-.5));
$('#wordCard').onclick=e=>{
  let jp=e.target.closest('[data-jump]');
  if(jp){
    stopAuto();
    openCards([BY_WORD[jp.dataset.jump]]);
    return
  }
  let b=e.target.closest('button');
  if(!b)return;
  let a=b.dataset.ca,x=cardPool[cardIndex];
  if(a==='auto'){
    cardAuto?stopAuto():startCardAuto();
    return
  }
  if(a!=='fav')stopAuto();
  if(a==='list'){
    renderWords();
    return
  }
  if(!x)return;
  if(a==='play')say(x.w,1);
  if(a==='slow')say(x.w,.62);
  if(a==='ex')say(x.ex,.95);
  if(a==='exslow')say(x.ex,.65);
  if(a==='reveal'){
    cardReveal=true;
    showCard();
    return
  }
  if(a==='fav'){
    toggleFav(x.w)
  }
  if(a&&a.startsWith('g-')){
    setStatus(x.w,a.slice(2));
    cardIndex++;
    cardReveal=false;
    if(cardIndex>=cardPool.length){
      cardPool=[];
      cardIndex=0
    }
    showCard();
    return
  }
  if(a==='next'){
    cardIndex=(cardIndex+1)%cardPool.length;
    cardReveal=false;
    showCard();
    return
  }
  if(a==='prev'){
    cardIndex=(cardIndex-1+cardPool.length)%cardPool.length;
    cardReveal=false;
    showCard();
    return
  }
  if(a==='fav'){
    let el=b;
    el.textContent=store.wordFav.includes(x.w)?'★ 已收藏':'☆ 收藏'
  }
};
/* ===== V5.16.14 進度備份與還原 =====
   匯出：app / version / schemaVersion / exportedAt / summary / progress，匯出前先自我檢查。
   匯入：檢查 JSON、是否為 English 5000 備份、是否有 progress、格式版本、各欄位型別；
         有問題一律不動目前紀錄。匯入或還原前先把目前紀錄存到「復原點」，可隨時復原。 */
function progSummary(p){
  p=p||{};
  const st=p.wordStatus&&typeof p.wordStatus==='object'?p.wordStatus:{};
  const n=a=>Array.isArray(a)?a.length:0,o=x=>x&&typeof x==='object'&&!Array.isArray(x)?Object.keys(x).length:0;
  const known=new Set([...(Array.isArray(p.wordKnown)?p.wordKnown:[]),...Object.keys(st).filter(k=>st[k]==='known')]);
  return {wordKnown:known.size,learning:Object.values(st).filter(v=>v==='learning').length,review:o(p.reviewDue),wordFav:n(p.wordFav),wrong:o(p.wrongWords),sentKnown:n(p.known),sentFav:n(p.fav),phKnown:n(p.phKnown),phFav:n(p.phFav),dlg:o(p.dlgDone),rp:o(p.rpDone),days:n(p.studyDays)}
}
function sumText(s){
  return `已熟單字 ${s.wordKnown}、學習中 ${s.learning}、複習排程 ${s.review}、收藏單字 ${s.wordFav}、答錯本 ${s.wrong}、會說的句子 ${s.sentKnown}、收藏句子 ${s.sentFav}、已會片語 ${s.phKnown}、收藏片語 ${s.phFav}、情境對話 ${s.dlg||0}、Role Play ${s.rp||0}、學習天數 ${s.days}`
}
function fmtTime(t){
  try{
    const d=new Date(t);
    if(isNaN(d))return '未知';
    return d.getFullYear()+'/'+(d.getMonth()+1)+'/'+d.getDate()+' '+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')
  }catch(e){
    return '未知'
  }
}
function makeBackup(){
  return {app:'english-5000',version:APP_VERSION,schemaVersion:BACKUP_SCHEMA,exportedAt:new Date().toISOString(),summary:progSummary(store),progress:JSON.parse(JSON.stringify(store))}
}
function checkBackup(text){
  let obj;
  try{
    obj=JSON.parse(text)
  }catch(e){
    return {err:'這不是有效的備份檔（JSON 格式錯誤，檔案可能損毀或沒有完整下載）。'}
  }
  if(!obj||typeof obj!=='object'||Array.isArray(obj))return {err:'這不是 English 5000 的備份檔。'};
  if(obj.app!=='english-5000')return {err:'這不是 English 5000 的備份檔。'};
  const p=obj.progress;
  if(!p||typeof p!=='object'||Array.isArray(p))return {err:'備份檔裡沒有學習進度（progress）。'};
  const sv=obj.schemaVersion==null?(p.wordKeyVersion>=3?3:2):Number(obj.schemaVersion);
  if(!(sv>=1)||Math.floor(sv)!==sv)return {err:'無法辨識備份檔的格式版本。'};
  if(sv>BACKUP_SCHEMA)return {err:`這個備份來自較新版本的 App（格式 ${sv}），請先更新 App 再匯入。`};
  const arr=['fav','known','wordFav','wordKnown','phFav','phKnown','studyDays'],objs=['wordStatus','reviewDue','reviewStage','wrongWords','sDue','sStage','pDue','pStage','settings','dailyLog','dlgDone','rpDone','sqWrong','lsWrong'];
  for(const k of arr)if(p[k]!=null&&!Array.isArray(p[k]))return {err:`備份檔內容不正確（${k} 格式錯誤）。`};
  for(const k of objs)if(p[k]!=null&&(typeof p[k]!=='object'||Array.isArray(p[k])))return {err:`備份檔內容不正確（${k} 格式錯誤）。`};
  if(!arr.concat(objs).some(k=>p[k]!=null))return {err:'備份檔裡沒有任何學習紀錄。'};
  return {obj,p,sv}
}
let bmTimer;
function backupMsg(t,kind){
  const el=$('#backupMsg');
  if(el){
    el.textContent=t;
    el.className='rec-msg'+(kind?' '+kind:' ok');
    el.hidden=!t
  }
  const w=$('#wordBackupMsg');
  if(w){
    w.textContent=t;
    w.className='rec-msg'+(kind?' '+kind:' ok');
    w.hidden=!t
  }
  clearTimeout(bmTimer);
  bmTimer=setTimeout(()=>{
    [el,w].forEach(e=>{
      if(e)e.hidden=true
    })
  },15000)
}
function writeProgress(p,note){
  if(!lsSet(PRE_KEY,JSON.stringify({savedAt:new Date().toISOString(),version:APP_VERSION,summary:progSummary(store),progress:store}))){
    backupMsg('❌ 手機儲存空間不足，無法先保存目前紀錄，已取消。目前的紀錄沒有變動。','warn');
    return false
  }
  saveLock();
  const np=normStore(JSON.parse(JSON.stringify(p)));
  if(!(np.wordKeyVersion>=2))np.wordKeyVersion=0;else if(np.wordKeyVersion<3)np.wordKeyVersion=2;
  if(!lsSet(STORE_KEY,JSON.stringify(np))){
    _svLock=false;
    backupMsg('❌ 手機儲存空間不足，無法寫入，目前的紀錄沒有變動。','warn');
    return false
  }
  try{
    sessionStorage.setItem('e5k_msg',note);
    sessionStorage.setItem('e5k_go','stats')
  }catch(e){}
  location.reload();
  return true
}
async function importBackupText(text){
  const r=checkBackup(text);
  if(r.err){
    backupMsg('❌ 無法匯入：'+r.err+'目前的紀錄沒有變動。','warn');
    return false
  }
  const s=progSummary(r.p),c=progSummary(store),when=fmtTime(r.obj.exportedAt);
  if(!confirm(`要匯入這個備份嗎？\n\n備份時間：${when}（App ${r.obj.version||'舊版'}）\n備份內容：${sumText(s)}\n\n目前紀錄：${sumText(c)}\n\n匯入會取代目前紀錄。目前紀錄會先保存為「復原點」，之後可以按「↩️ 復原到匯入前」還原。`)){
    backupMsg('已取消匯入，目前的紀錄沒有變動。');
    return false
  }
  return writeProgress(r.p,`✅ 已匯入 ${when} 的備份。（${sumText(s)}）`)
}
function restoreFrom(p,label){
  if(!confirm(`要還原到「${label}」嗎？\n\n內容：${sumText(progSummary(p))}\n\n目前紀錄會先保存為「復原點」，之後可以再復原。`))return false;
  return writeProgress(p,`✅ 已還原到「${label}」。`)
}
function exportBackup(share){
  const b=makeBackup(),txt=JSON.stringify(b,null,1);
  const chk=checkBackup(txt);
  if(chk.err){
    backupMsg('❌ 匯出失敗：備份檔自我檢查沒有通過（'+chk.err+'）','warn');
    return
  }
  const d=new Date(),name='english-5000-backup-'+d.getFullYear()+String(d.getMonth()+1).padStart(2,'0')+String(d.getDate()).padStart(2,'0')+'-'+String(d.getHours()).padStart(2,'0')+String(d.getMinutes()).padStart(2,'0')+'.json';
  const done=how=>{
    store.lastExport=day();
    store.lastExportName=name;
    save();
    if($('#statsPage')&&!$('#statsPage').hidden)renderBackup();
    backupMsg(`✅ ${how}：${name}（${sumText(b.summary)}）`+(how.includes('分享')?'\n之後要匯入時：按「📥 匯入備份檔」→ 檔案視窗下方點「瀏覽」→「最近項目」，或在上方搜尋 english-5000。':''))
  };
  const dl=()=>{
    const blob=new Blob([txt],{type:'application/json'}),a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(()=>URL.revokeObjectURL(a.href),4000);
    done('已下載備份檔')
  };
  if(share&&navigator.canShare&&window.File){
    try{
      const f=new File([txt],name,{type:'application/json'});
      if(navigator.canShare({files:[f]})){
        navigator.share({files:[f],title:'English 5000 學習紀錄備份'}).then(()=>done('已分享／儲存備份檔')).catch(e=>{
          if(e&&e.name==='AbortError')backupMsg('已取消分享。');else dl()
        });
        return
      }
    }catch(e){}
  }
  dl()
}
function backupText(){
  const b=makeBackup();
  return JSON.stringify(b)
}
async function copyBackup(){
  const txt=backupText();
  const chk=checkBackup(txt);
  if(chk.err){
    backupMsg('❌ 複製失敗：'+chk.err,'warn');
    return
  }
  let okc=false;
  try{
    if(navigator.clipboard&&navigator.clipboard.writeText){
      await navigator.clipboard.writeText(txt);
      okc=true
    }
  }catch(e){}
  if(!okc){
    const ta=$('#bkPaste');
    if(ta){
      ta.value=txt;
      ta.select();
      try{
        okc=document.execCommand('copy')
      }catch(e){}
    }
  }
  if(okc){
    store.lastExport=day();
    save();
    backupMsg('✅ 已複製備份內容（'+Math.round(txt.length/1024)+' KB）。可以貼到「備忘錄」或傳給自己保存；還原時把整段內容貼到下方「貼上備份內容」再按匯入。')
  }else backupMsg('❌ 這個瀏覽器不允許自動複製，請改用「💾 匯出備份檔」。','warn')
}
function renderBackup(){
  const box=$('#backupBody');
  if(!box)return;
  const s=progSummary(store),le=store.lastExport;
  const pre=(()=>{
    try{
      return JSON.parse(lsGet(PRE_KEY)||'null')
    }catch(e){
      return null
    }
  })();
  const snaps=snapMeta();
  const canShare=!!(navigator.canShare&&window.File);
  box.innerHTML=`<p class="muted">學習紀錄只存在這支手機的瀏覽器裡。清除瀏覽資料、換手機或換瀏覽器前，請先匯出備份檔。</p>
 <div class="bk-sum"><b>目前紀錄</b><small>${esc(sumText(s))}</small><small>上次匯出：${le?esc(le):'尚未匯出'}</small></div>
 <div class="grid2"><button id="bkExport" class="primary">💾 匯出備份檔</button>${canShare?'<button id="bkShare">📤 分享／存到「檔案」</button>':''}<label class="importBtn bk-import">📥 匯入備份檔<input id="bkImport" type="file" hidden></label><button id="bkCopy">📋 複製備份內容</button>${pre&&pre.progress?`<button id="bkUndo">↩️ 復原到 ${esc(fmtTime(pre.savedAt))} 匯入／還原前</button>`:''}</div>
 <p class="muted bk-hint">📁 <b>找不到備份檔？</b>按「📥 匯入備份檔」後，在檔案視窗下方點「瀏覽」→「最近項目」，或在上方搜尋 <b>english-5000</b>；也可到「我的 iPhone」或 iCloud Drive 找（用 Edge 存的檔案常在「我的 iPhone › Edge」）。${store.lastExportName?'<br>上次匯出的檔名：<b>'+esc(store.lastExportName)+'</b>':''}</p>
 <div id="backupMsg" class="rec-msg" role="status" aria-live="polite" hidden></div>
 <details class="bk-paste"><summary>📝 貼上備份內容匯入（不用檔案）</summary><textarea id="bkPaste" rows="4" placeholder="把「📋 複製備份內容」複製的整段文字貼在這裡"></textarea><button id="bkPasteGo">匯入貼上的內容</button></details>
 <h3>自動備份（每天第一次開啟時保存，保留 3 天）</h3>${snaps.length?snaps.map((x,k)=>`<div class="bk-row"><span><b>${esc(x.date)}</b><small>${esc(sumText(x.summary))}</small></span><button data-snap="${k}">還原</button></div>`).join(''):'<p class="muted">還沒有自動備份（明天開啟時會自動建立）。</p>'}`;
  $('#bkExport').onclick=()=>exportBackup(false);
  $('#bkCopy').onclick=copyBackup;
  $('#bkPasteGo').onclick=()=>{
    const t=$('#bkPaste').value.trim();
    if(!t){
      backupMsg('請先把備份內容貼到上方的框裡。','warn');
      return
    }
    importBackupText(t)
  };
  const sh=$('#bkShare');
  if(sh)sh.onclick=()=>exportBackup(true);
  $('#bkImport').onchange=async e=>{
    const f=e.target.files&&e.target.files[0];
    e.target.value='';
    if(!f)return;
    let t;
    try{
      t=await f.text()
    }catch(x){
      backupMsg('❌ 無法讀取檔案，目前的紀錄沒有變動。','warn');
      return
    }
    importBackupText(t)
  };
  const u=$('#bkUndo');
  if(u)u.onclick=()=>restoreFrom(pre.progress,fmtTime(pre.savedAt)+' 匯入／還原前的紀錄');
  box.querySelectorAll('[data-snap]').forEach(b=>b.onclick=()=>{
    const m=snaps[+b.dataset.snap];
    const x=snapList().find(y=>y.date===m.date);
    if(!x){
      backupMsg('❌ 找不到這份自動備份，請重新開啟統計頁。','warn');
      return
    }
    restoreFrom(x.progress,x.date+' 自動備份')
  })
}
$('#exportProgress').onclick=()=>exportBackup(false);
$('#importProgress').onchange=async e=>{
  const f=e.target.files&&e.target.files[0];
  e.target.value='';
  if(!f)return;
  let t;
  try{
    t=await f.text()
  }catch(x){
    backupMsg('❌ 無法讀取檔案，目前的紀錄沒有變動。','warn');
    return
  }
  importBackupText(t)
};
/* 單字測驗：英→中、中→英、聽音選字（只使用已有中文的單字） */
function lev(a,b){
  if(Math.abs(a.length-b.length)>3)return 9;
  let d=[...Array(b.length+1).keys()];
  for(let i=1;i<=a.length;i++){
    let p=d[0];
    d[0]=i;
    for(let j=1;j<=b.length;j++){
      let t=d[j];
      d[j]=Math.min(d[j]+1,d[j-1]+1,p+(a[i-1]===b[j-1]?0:1));
      p=t
    }
  }
  return d[b.length]
}
function pickOpts(x,pool,n=3){
  let p1=(x.pos||'').split('/')[0];
  let cand=pool.filter(y=>y.w!==x.w&&y.zh!==x.zh);
 /* V5.16.16 效能：只對「開頭字母相同、字尾相同或長度相近」的候選字計算拼字相似度，其餘隨機抽樣，結果與原本相同等級的相近選項 */
  if(cand.length>500){
    const a=x.w[0],e2=x.w.slice(-2),L=x.w.length;
    const near=[],rest=[];
    for(const y of cand){
      if(y.w[0]===a||y.w.slice(-2)===e2)near.push(y);else rest.push(y)
    }
    for(let k=rest.length-1;k>0;k--){
      const j=Math.floor(Math.random()*(k+1));
      [rest[k],rest[j]]=[rest[j],rest[k]]
    }
    cand=near.concat(rest.slice(0,Math.max(150,500-near.length)))
  }
  let sc=cand.map(y=>{
    let s=Math.random()*1.5;
    if((y.pos||'').split('/')[0]===p1)s+=3;
    if(y.w[0]===x.w[0])s+=1;
    if(y.w.slice(0,3)===x.w.slice(0,3))s+=2;
    let L=lev(x.w,y.w);
    if(L<=2)s+=3;else if(L<=3)s+=1.5;
    if(Math.abs(y.w.length-x.w.length)<=1)s+=.5;
    return [s,y]
  }).sort((a,b)=>b[0]-a[0]);
  let top=sc.slice(0,12).map(v=>v[1]).sort(()=>Math.random()-.5);
  return top.slice(0,n)
}
const _qpC={};
function quizPool(){
  let book=$('#quizBook').value;
  if(book==='wrong'){
    const ws=store.wrongWords||{};
    return WORDS.filter(x=>ws[x.w])
  }
  const k=book+'|'+skipV();
  if(_qpC[k])return _qpC[k];
  let p=WORDS.filter(x=>x.zh);
  p=p.filter(x=>inBook(x,book)&&!(skipV()&&x.b));
  return _qpC[k]=p
}
function quizResult(x,ok,extra=''){
  store.wrongWords=store.wrongWords||{};
  if(ok){
    $('#quizMsg').innerHTML=`✅ 答對了！ ${esc(dispW(x.w))}｜${esc(x.zh)}${x.ex?'<br><small>'+esc(x.ex)+'</small>':''}`;
    store.quizRight=(store.quizRight||0)+1;
    if(store.wrongWords[x.w]){
      store.wrongWords[x.w]--;
      if(store.wrongWords[x.w]<=0)delete store.wrongWords[x.w]
    }
  }else{
    $('#quizMsg').innerHTML=`❌ 正確答案：${esc(dispW(x.w))}｜${esc(x.zh)}${extra}<br><small>已加入複習與答錯單字本</small>`;
    setStatus(x.w,'learning',true);
    store.quizWrong=(store.quizWrong||0)+1;
    store.wrongWords[x.w]=(store.wrongWords[x.w]||0)+2
  }
  bumpLog('quiz');
  markStudy();
  save();
  say(x.w,1)
}
function wordQuiz(){
  let pool=quizPool();
  let book=$('#quizBook').value;
  if(book==='wrong'&&!pool.length){
    $('#quizQ').innerHTML='🎉 答錯單字本是空的';
    $('#quizOpts').innerHTML='';
    $('#quizMsg').textContent='';
    return
  }
  let base=book==='wrong'?WORDS:pool;
  if(pool.length<1||base.length<4){
    $('#quizQ').textContent='此範圍題目不足';
    $('#quizOpts').innerHTML='';
    return
  }
  let mode=$('#quizMode').value;
  if(mode==='mix')mode=['en','zh','listen','cloze','dict'][Math.floor(Math.random()*5)];
  let x=pool[Math.floor(Math.random()*pool.length)];
  $('#quizMsg').textContent='';
  if(mode==='dict'){
    $('#quizQ').innerHTML=`🎧 聽寫：聽發音，拼出單字 <button id="quizReplay">再聽</button> <button id="quizSlow">🐢 慢速</button><br><small>提示：${esc(x.zh)}（${x.w.length} 個字母，開頭 ${esc(x.w[0])}）</small>`;
    $('#quizOpts').innerHTML=`<input id="dictIn" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="輸入你聽到的單字"><button id="dictGo" class="primary">確認</button>`;
    say(x.w,.85);
    setTimeout(()=>{
      $('#quizReplay').onclick=()=>say(x.w,.85);
      $('#quizSlow').onclick=()=>say(x.w,.6);
      let inp=$('#dictIn');
      inp.focus();
      const go=()=>{
        let v=inp.value.trim().toLowerCase().replace(/[’]/g,"'");
        if(!v)return;
        inp.disabled=true;
        $('#dictGo').disabled=true;
        quizResult(x,v===x.w.toLowerCase(),`<br><small>你寫的是：${esc(v)}</small>`)
      };
      $('#dictGo').onclick=go;
      inp.onkeydown=e=>{
        if(e.key==='Enter')go()
      }
    },0);
    $('#quizOpts').onclick=null;
    return
  }
  let opts=[x,...pickOpts(x,base)].sort(()=>Math.random()-.5);
  if(mode==='en'){
    $('#quizQ').innerHTML=`${esc(dispW(x.w))} <small>${x.p?'/'+esc(x.p)+'/':''}</small>`
  }else if(mode==='zh'){
    $('#quizQ').innerHTML=esc(x.zh)
  }else if(mode==='cloze'){
    $('#quizQ').innerHTML=hl(x).replace(/<mark>.*?<\/mark>/,'<span class="blank">_____</span>')+`<br><small>${esc(x.exz)}</small>`
  }else{
    $('#quizQ').innerHTML='🔊 聽發音，選出單字 <button id="quizReplay">再聽</button>';
    say(x.w,.9);
    setTimeout(()=>{
      let r=$('#quizReplay');
      if(r)r.onclick=()=>say(x.w,.75)
    },0)
  }
  $('#quizOpts').innerHTML=opts.map(o=>`<button data-ok="${o.w===x.w}">${mode==='en'?esc(o.zh):esc(dispW(o.w))}</button>`).join('');
  let done=false;
  $('#quizOpts').onclick=e=>{
    let b=e.target.closest('button');
    if(!b||done)return;
    done=true;
    let ok=b.dataset.ok==='true';
    b.classList.add(ok?'opt-ok':'opt-bad');
    if(!ok)$('#quizOpts').querySelector('[data-ok=true]').classList.add('opt-ok');
    quizResult(x,ok)
  }
}
function runQuiz(){
  let t=$('#quizType').value;
  if(window.P6QUIZ&&window.P6QUIZ[t])return window.P6QUIZ[t]();
  t==='word'?wordQuiz():t==='phrase'?phraseQuiz():quiz()
}
$('#newQuiz').onclick=runQuiz;
['quizType','quizMode','quizBook'].forEach(id=>$('#'+id).onchange=()=>{
  let t=$('#quizType').value;
  $('#quizWordOpts').hidden=t!=='word'&&t!=='phrase';
  $('#quizBook').hidden=t!=='word';
  const sr=$('#quizSOpts');
  if(sr)sr.hidden=t!=='lisen'&&t!=='liszh';
  const s2=$('#quizSitOpts');
  if(s2)s2.hidden=t!=='situ';
  const s3=$('#quizDcOpts');
  if(s3)s3.hidden=t!=='dcloze';
  runQuiz()
});
$('#navQuiz').onclick=()=>{
  page('quiz');
  runQuiz()
};

/* ===== V5.11：學習紀錄、片語、統計、聲音設定 ===== */
function markStudy(){
  store.studyDays=store.studyDays||[];
  let t=day();
  if(!store.studyDays.includes(t)){
    store.studyDays.push(t);
    if(store.studyDays.length>400)store.studyDays=store.studyDays.slice(-400);
    save()
  }
}
function streak(){
  let d=new Set(store.studyDays||[]),n=0,off=d.has(day())?0:-1;
  while(d.has(day(off-n)))n++;
  return n
}
store.phFav=store.phFav||[];
store.phKnown=store.phKnown||[];
const PH_CAT={daily:'日常',work:'工作',ce:'CE 現場'};
let phShown=40;
function phFiltered(){
  let q=$('#phSearch').value.trim().toLowerCase(),c=$('#phCat').value,st=$('#phState').value;
  return PHRASES.filter(x=>(!q||x.p.toLowerCase().includes(q)||x.zh.includes(q)||x.ex.toLowerCase().includes(q))&&(c==='all'||x.cat===c)&&(st==='all'||(st==='fav'&&store.phFav.includes(x.id))||(st==='due'&&isPDue(x.id))||(st==='known'&&store.phKnown.includes(x.id))||(st==='new'&&!store.phKnown.includes(x.id))))
}
function renderPhrases(){
  let a=phFiltered();
  $('#phCount').textContent=a.length;
  $('#phKnownN').textContent=store.phKnown.length;
  $('#phRows').innerHTML=a.slice(0,phShown).map(x=>`<div class="word-card ${store.phKnown.includes(x.id)?'status-known':'status-new'}" data-id="${x.id}"><span class="word-rank">${PH_CAT[x.cat]}</span><span class="word-main"><strong>${esc(x.p)}</strong><span class="zh">${esc(x.zh)}${isPDue(x.id)?' <em class="duetag">待複習</em>':''}</span><span class="ex">${esc(x.ex)}<br><small>${esc(x.exz)}</small></span></span><span class="word-actions"><button data-a="play">🔊</button><button data-a="ex">💬</button><button data-a="slow">🐢</button><button data-a="fav">${store.phFav.includes(x.id)?'★':'☆'}</button>${isPDue(x.id)?'<button data-a="pok" class="g3">✓還會</button><button data-a="pno" class="g1">✗忘了</button>':`<button data-a="known">${store.phKnown.includes(x.id)?'✓':'○'}</button>`}</span></div>`).join('');
  $('#phMore').hidden=phShown>=a.length
}
['phSearch','phCat','phState'].forEach(id=>$('#'+id).addEventListener(id==='phSearch'?'input':'change',id==='phSearch'?debounce(()=>{
  phShown=40;
  renderPhrases()
},150):()=>{
  phShown=40;
  renderPhrases()
}));
$('#phMore').onclick=()=>{
  phShown+=60;
  renderPhrases()
};
$('#phRows').onclick=e=>{
  let b=e.target.closest('button'),row=e.target.closest('.word-card');
  if(!b||!row)return;
  let id=+row.dataset.id,x=PHRASES[id-1],a=b.dataset.a;
  if(a==='play')say(x.p,.95);
  if(a==='ex')say(x.ex,.95);
  if(a==='slow')say(x.ex,.65);
  const tg=k=>{
    let arr=store[k],n=arr.indexOf(id);
    n<0?arr.push(id):arr.splice(n,1);
    save();
    renderPhrases()
  };
  if(a==='fav')tg('phFav');
  if(a==='known'){
    let was=store.phKnown.includes(id);
    if(was)srsDel('p',id);else srsSet('p',id,1);
    tg('phKnown');
    markStudy();
    if(!was)bumpLog('ph')
  }
  if(a==='pok'){
    srsSet('p',id,srsStage('p',id)+1);
    bumpLog('prev');
    markStudy();
    save();
    renderPhrases()
  }
  if(a==='pno'){
    srsDel('p',id);
    store.phKnown=store.phKnown.filter(v=>v!==id);
    bumpLog('prev');
    markStudy();
    save();
    renderPhrases()
  }
};
$('#navPhrases').onclick=()=>{
  page('phrases');
  phShown=40;
  renderPhrases()
};
function bar(n,t){
  let pc=t?Math.round(n/t*100):0;
  return `<div class="bar"><span style="width:${pc}%"></span></div><small>${n} / ${t}（${pc}%）</small>`
}
function renderStats(){
  let r=store.quizRight||0,w=store.quizWrong||0,tot=r+w;
  const sv=skipV();
  const inB=(x,b)=>inBook(x,String(b))&&!(sv&&x.b);
  let books=[1,2,3,4,5,7].map(b=>{
    let a=WORDS.filter(x=>inB(x,b));
    let k=a.filter(x=>statusOf(x.w)==='known').length;
    return `<div class="stat-row"><b>${b===7?'CE 字':'第 '+b+' 冊'}</b>${bar(k,a.length)}</div>`
  }).join('');
  let allW=WORDS.filter(x=>inB(x,'all')),allK=allW.filter(x=>statusOf(x.w)==='known').length;
  let learning=WORDS.filter(x=>statusOf(x.w)==='learning').length,due=WORDS.filter(x=>isDue(x.w)).length;
  $('#statsBody').innerHTML=`<div class="stat-cards"><div><b>${streak()}</b><span>連續學習天數</span></div><div><b>${(store.studyDays||[]).length}</b><span>累計學習天數</span></div><div><b>${tot?Math.round(r/tot*100)+'%':'—'}</b><span>測驗正確率（${r}/${tot}）</span></div></div><h3>單字（已熟）${sv?'<small class="muted">　只計原形</small>':''}</h3>${books}<div class="stat-row"><b>合計</b>${bar(allK,allW.length)}</div><p class="muted">學習中 ${learning} 字 · 今日待複習 ${due} 字</p><h3>片語</h3><div class="stat-row"><b>已會</b>${bar(store.phKnown.length,PHRASES.length)}</div><p class="muted">待複習片語 ${PHRASES.filter(x=>isPDue(x.id)).length} 個</p><h3>句子</h3><div class="stat-row"><b>會說了</b>${bar(store.known.length,ALLS.length)}</div><p class="muted">待複習句子 ${ALLS.filter(s=>isSDue(s.id)).length} 句</p>`
}
$('#navStats').onclick=()=>{
  page('stats');
  renderStats();
  fillVoices();
  verCheck();
  renderBackup()
};
function fillVoices(){
  let sel=$('#voiceSel');
  if(!sel)return;
  let cur=pickVoice();
  sel.innerHTML=voices.length?voices.map(v=>`<option value="${esc(v.voiceURI)}"${cur&&v.voiceURI===cur.voiceURI?' selected':''}>${esc(v.name)}（${esc(v.lang)}）</option>`).join(''):'<option>此裝置沒有可用的英文語音</option>'
}
$('#voiceSel').onchange=e=>{
  store.settings.voice=e.target.value;
  save();
  say('Hello, this is my new voice.',1)
};
$('#voiceTest').onclick=()=>say('Please check the system status.',1);

/* ===== V5.13：今日學習、答錯單字本、備份提醒、深色模式 ===== */
function bumpLog(k){
  store.dailyLog=store.dailyLog||{};
  let t=day();
  let L=store.dailyLog[t]=store.dailyLog[t]||{};
  L[k]=(L[k]||0)+1;
  let ks=Object.keys(store.dailyLog).sort();
  if(ks.length>60)delete store.dailyLog[ks[0]];
  save()
}
function todayLog(){
  return (store.dailyLog||{})[day()]||{}
}
function task(icon,title,done,goal,btn,id,note=''){
  let ok=goal&&done>=goal;
  let pc=goal?Math.min(100,Math.round(done/goal*100)):0;
  return `<div class="task ${ok?'task-done':''}"><div class="task-top"><span class="task-ic">${icon}</span><div class="task-t"><b>${title}</b><small>${goal?`${Math.min(done,goal)} / ${goal}`:note}${ok?' ✅':''}</small></div><button class="primary" data-go="${id}">${btn}</button></div>${goal?`<div class="bar"><span style="width:${pc}%"></span></div>`:''}</div>`
}
function renderToday(){
  let sdue=ALLS.filter(s=>isSDue(s.id)).length,pdue=PHRASES.filter(x=>isPDue(x.id)).length;
  let L=todayLog(),due=WORDS.filter(x=>isDue(x.w)).length,wrong=Object.keys(store.wrongWords||{}).length,g=store.settings.dailyGoal||20;
  let d=new Date(),wd='日一二三四五六'[d.getDay()];
  let dueDone=L.review||0;
  let backup='';
  let le=store.lastExport;
  let days=le?Math.floor((new Date(day())-new Date(le))/86400000):null;
  if((store.studyDays||[]).length>=2&&(days===null||days>=7))backup=`<div class="backup"><b>💾 建議備份學習進度</b><small>${days===null?'你還沒有備份過。':'距離上次備份已 '+days+' 天。'}學習紀錄只存在這支手機的瀏覽器裡，清除瀏覽資料就會消失。</small><button data-go="backup">立即匯出備份</button></div>`;
  $('#todayBody').innerHTML=`<div class="today-head"><div><b>${d.getMonth()+1} 月 ${d.getDate()} 日（${wd}）</b><small>連續學習 ${streak()} 天</small></div><div class="ring"><b>${['new','review','sent','ph','quiz','srev','prev'].reduce((s,k)=>s+(L[k]||0),0)}</b><small>今日完成</small></div></div>${backup}
${task('🔁','複習到期單字',dueDone,dueDone+due,due?'開始複習':'已完成','review',due?'':'今天沒有到期的字')}
${task('🆕','學新單字',L.new||0,g,'開始','new')}
${task('🗣','句子跟讀（標記會說）',L.sent||0,10,'開始','sent')}
${task('💬','片語（標記已會）',L.ph||0,5,'開始','ph')}
${sdue?task('🔁','複習句子（到期）',L.srev||0,(L.srev||0)+sdue,'開始','srev'):''}
${pdue?task('🔁','複習片語（到期）',L.prev||0,(L.prev||0)+pdue,'開始','prev'):''}
${task('🧠','測驗',L.quiz||0,10,'開始','quiz')}
${wrong?task('📕','答錯單字本',0,0,'練習','wrong',`目前有 ${wrong} 個字`):''}
<p class="muted">每日新字數量可在「單字」頁調整（目前 ${g} 字）。</p>`
}
$('#todayBody').onclick=e=>{
  let b=e.target.closest('[data-go]');
  if(!b)return;
  let g=b.dataset.go;
  if(g==='review'){
    page('words');
    renderWords();
    $('#reviewStart').click()
  }
else if(g==='srev'){
    page('practice');
    $('#unit').value='sdue';
    i=0;
    filter();
    render()
  }
else if(g==='prev'){
    $('#navPhrases').click();
    $('#phSearch').value='';
    $('#phCat').value='all';
    $('#phState').value='due';
    phShown=40;
    renderPhrases()
  }
else if(g==='new'){
    page('words');
    renderWords();
    $('#dailyStart').click()
  }
else if(g==='sent'){
    page('practice');
    if(!$('#hideKnown').checked){
      $('#hideKnown').checked=true;
      store.settings.hideKnown=true;
      save();
      filter()
    }
    render()
  }
else if(g==='ph'){
    $('#navPhrases').click();
    $('#phSearch').value='';
    $('#phCat').value='all';
    $('#phState').value='new';
    phShown=40;
    renderPhrases()
  }
else if(g==='quiz'){
    page('quiz');
    $('#quizType').value='word';
    if($('#quizBook').value==='wrong')$('#quizBook').value='all';
    $('#quizType').onchange()
  }
else if(g==='wrong'){
    page('quiz');
    $('#quizType').value='word';
    $('#quizBook').value='wrong';
    $('#quizMode').value='mix';
    $('#quizType').onchange()
  }
else if(g==='backup'){
    $('#exportProgress').click();
    setTimeout(renderToday,300)
  }
};
$('#navToday').onclick=()=>{
  page('today');
  renderToday()
};
function applyTheme(){
  let m=store.settings.theme||'auto';
  let dark=m==='dark'||(m==='auto'&&window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.classList.toggle('dark',dark);
  let mc=document.querySelector('meta[name=theme-color]');
  if(mc)mc.content=dark?'#0f1a2b':'#2f69d5'
}
$('#themeSel').value=store.settings.theme||'auto';
$('#themeSel').onchange=e=>{
  store.settings.theme=e.target.value;
  save();
  applyTheme()
};
if(window.matchMedia)matchMedia('(prefers-color-scheme: dark)').addEventListener&&matchMedia('(prefers-color-scheme: dark)').addEventListener('change',applyTheme);
applyTheme();

/* ===== V5.14：句子／片語複習排程、片語測驗、CE 專業字、自動播放、詞形與相關字、主題 ===== */
store.sStage=store.sStage||{};
store.sDue=store.sDue||{};
store.pStage=store.pStage||{};
store.pDue=store.pDue||{};
function srsStage(k,id){
  return (store[k+'Stage']||{})[id]||0
}
function srsSet(k,id,st){
  st=Math.max(1,Math.min(st,INTERVALS.length-1));
  store[k+'Stage'][id]=st;
  store[k+'Due'][id]=day(INTERVALS[st]);
  save()
}
function srsDel(k,id){
  delete store[k+'Stage'][id];
  delete store[k+'Due'][id];
  save()
}
function isSDue(id){
  return !!(store.sDue&&store.sDue[id]&&store.sDue[id]<=day()&&cset('known').has(id))
}
function isPDue(id){
  return !!(store.pDue&&store.pDue[id]&&store.pDue[id]<=day()&&cset('phKnown').has(id))
}
(function migrate514(){
  if(store.srsV===514)return;
  store.known.forEach((id,n)=>{
    if(!store.sDue[id]){
      store.sStage[id]=1;
      store.sDue[id]=day(1+n%7)
    }
  });
  store.phKnown.forEach((id,n)=>{
    if(!store.pDue[id]){
      store.pStage[id]=1;
      store.pDue[id]=day(1+n%7)
    }
  });
  store.srsV=514;
  save()
})();
$('#sOk').onclick=()=>{
  let id=cur().id;
  srsSet('s',id,srsStage('s',id)+1);
  bumpLog('srev');
  markStudy();
  filter();
  render()
};
$('#sNo').onclick=()=>{
  let id=cur().id;
  srsDel('s',id);
  store.known=store.known.filter(v=>v!==id);
  bumpLog('srev');
  markStudy();
  save();
  filter();
  render()
};
const VS={};
WORDS.forEach(x=>{
  if(x.b)(VS[x.b]=VS[x.b]||[]).push(x.w)
});
function bookName(x){
  return x.ce?'CE 專業字':'#'+x.r+' · 第 '+x.k+' 冊'
}
function chip(w){
  return `<a data-jump="${esc(w)}">${esc(dispW(w))}</a>`
}
function relHtml(x){
  let h='';
  if(x.b)h+=`<span class="rel">原形 ${chip(x.b)}</span>`;
  if(VS[x.w])h+=`<span class="rel">詞形 ${VS[x.w].map(chip).join('、')}</span>`;
  if(x.f)h+=`<span class="rel">相關字 ${x.f.map(chip).join('、')}</span>`;
  return h?`<div class="rels">${h}</div>`:''
}
const TOPIC_N={};
WORDS.forEach(x=>{
  if(x.t)x.t.forEach(k=>{
    TOPIC_N[k]=(TOPIC_N[k]||0)+1
  })
});
$('#wordTopic').innerHTML='<option value="all">全部主題</option>'+Object.entries(TOPICS).map(([k,v])=>`<option value="${k}">${v}（${TOPIC_N[k]||0}）</option>`).join('');
$('#skipVar').checked=skipV();
$('#skipVar').onchange=()=>{
  store.settings.skipVar=$('#skipVar').checked;
  save();
  wordShown=60;
  renderWords()
};
/* 自動播放 */
let autoOn=false,cardAuto=false,autoTok=0;
function zhVoice(){
  let vs=speechSynthesis.getVoices();
  return vs.find(v=>/zh[-_](TW|HK)/i.test(v.lang))||vs.find(v=>/^zh/i.test(v.lang))||vs.find(v=>/^cmn/i.test(v.lang))
}
function speakCb(t,rate,lang,cb){
  let done=false;
  const fin=()=>{
    if(done)return;
    done=true;
    cb&&cb()
  };
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(t);
  u.rate=rate;
  if(lang==='zh'){
    let v=zhVoice();
    if(!v){
      fin();
      return
    }
    u.voice=v;
    u.lang=v.lang
  }else{
    const pv=pickVoice();
    u.lang='en-US';
    if(pv){
      u.voice=pv;
      u.lang=pv.lang
    }
  }
  u.onend=fin;
  u.onerror=fin;
  speechSynthesis.speak(u);
  setTimeout(fin,Math.max(2500,t.length*(lang==='zh'?300:110)/rate+1800))
}
function steps(list,tok,cb){
  let k=0;
  const nx=()=>{
    if(tok!==autoTok)return;
    if(k>=list.length){
      cb&&cb();
      return
    }
    let s=list[k++];
    if(s.wait){
      setTimeout(nx,s.wait);
      return
    }
    speakCb(s.t,s.r||1,s.l,()=>setTimeout(nx,350))
  };
  nx()
}
function stopAuto(){
  autoTok++;
  if(autoOn){
    autoOn=false;
    $('#autoPlay').textContent='▶ 自動播放';
    $('#autoPlay').classList.remove('primary')
  }
  if(cardAuto){
    cardAuto=false;
    if(!$('#wordCard').hidden&&cardPool.length)showCard()
  }
  try{
    speechSynthesis.cancel()
  }catch(e){}
}
function autoSentence(){
  if(!autoOn)return;
  if($('.panel').hidden){
    stopAuto();
    return
  }
  let s=cur(),tok=autoTok,rep=+(store.settings.autoRep||2);
  let L=[{t:s.en,r:1}];
  if(rep>=2)L.push({wait:500},{t:s.en,r:.7});
  if(store.settings.autoZh)L.push({wait:300},{t:s.zh,l:'zh'});
  L.push({wait:1200});
  steps(L,tok,()=>{
    if(tok!==autoTok||!autoOn)return;
    i=(i+1)%pool.length;
    render();
    autoSentence()
  })
}
$('#autoPlay').onclick=()=>{
  if(autoOn){
    stopAuto();
    return
  }
  stopAuto();
  autoOn=true;
  $('#autoPlay').textContent='⏸ 停止自動';
  $('#autoPlay').classList.add('primary');
  autoSentence()
};
function startCardAuto(){
  stopAuto();
  cardAuto=true;
  cardReveal=true;
  showCard();
  cardStep()
}
function cardStep(){
  if(!cardAuto||$('#wordCard').hidden||!cardPool.length){
    stopAuto();
    return
  }
  let x=cardPool[cardIndex],tok=autoTok;
  let L=[{t:x.w,r:1},{wait:400},{t:x.w,r:.65}];
  if(store.settings.autoZh)L.push({wait:300},{t:x.zh.replace(/（.*?）/g,''),l:'zh'});
  if(x.ex)L.push({wait:400},{t:x.ex,r:.95});
  L.push({wait:1200});
  steps(L,tok,()=>{
    if(tok!==autoTok||!cardAuto)return;
    cardIndex=(cardIndex+1)%cardPool.length;
    cardReveal=true;
    showCard();
    cardStep()
  })
}
/* V5.16.20：在「捕獲階段」先停止自動播放，避免把按鈕剛開始的發音取消；錄音、標記、收藏、複習、換單元也會停止句子自動播放 */
$('nav').addEventListener('click',e=>{
  if(e.target.closest('button'))stopAuto()
},true);
document.addEventListener('click',e=>{
  if(autoOn&&e.target.closest('#prev,#next,#play,#slow,#repeat,#check,#record,#mine,#compare,#known,#fav,#sOk,#sNo,#openList'))stopAuto()
},true);
['unit','hideKnown'].forEach(id=>$('#'+id).addEventListener('change',()=>{
  if(autoOn)stopAuto()
}));
$('#autoZh').checked=!!store.settings.autoZh;
$('#autoZh').onchange=()=>{
  store.settings.autoZh=$('#autoZh').checked;
  save()
};
$('#autoRep').value=String(store.settings.autoRep||2);
$('#autoRep').onchange=()=>{
  store.settings.autoRep=+$('#autoRep').value;
  save()
};
/* 片語測驗 */
function phraseQuiz(){
  let mode=$('#quizMode').value;
  if(mode==='dict')mode='listen';
  if(mode==='mix')mode=['en','zh','cloze','listen'][Math.floor(Math.random()*4)];
  let x=PHRASES[Math.floor(Math.random()*PHRASES.length)];
  let re=new RegExp('\\b'+x.p.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b','i');
  if(mode==='cloze'&&!re.test(x.ex))mode='zh';
  let same=PHRASES.filter(y=>y.id!==x.id&&y.cat===x.cat&&y.zh!==x.zh).sort(()=>Math.random()-.5).slice(0,3);
  let opts=[x,...same].sort(()=>Math.random()-.5);
  $('#quizMsg').textContent='';
  if(mode==='en')$('#quizQ').innerHTML=esc(x.p);else if(mode==='zh')$('#quizQ').innerHTML=esc(x.zh);else if(mode==='cloze')$('#quizQ').innerHTML=esc(x.ex).replace(re,'<span class="blank">_____</span>')+`<br><small>${esc(x.exz)}</small>`;else{
    $('#quizQ').innerHTML='🔊 聽片語，選出正確的片語 <button id="quizReplay">再聽</button>';
    say(x.p,.9);
    setTimeout(()=>{
      let r=$('#quizReplay');
      if(r)r.onclick=()=>say(x.p,.7)
    },0)
  }
  $('#quizOpts').innerHTML=opts.map(o=>`<button data-ok="${o.id===x.id}">${mode==='en'?esc(o.zh):esc(o.p)}</button>`).join('');
  let done=false;
  $('#quizOpts').onclick=e=>{
    let b=e.target.closest('button');
    if(!b||done)return;
    done=true;
    let ok=b.dataset.ok==='true';
    b.classList.add(ok?'opt-ok':'opt-bad');
    if(!ok)$('#quizOpts').querySelector('[data-ok=true]').classList.add('opt-ok');
    store[ok?'quizRight':'quizWrong']=(store[ok?'quizRight':'quizWrong']||0)+1;
    if(!ok&&store.phKnown.includes(x.id)){
      store.pDue[x.id]=day();
      store.pStage[x.id]=1
    }
    $('#quizMsg').innerHTML=`${ok?'✅ 答對了！':'❌ 正確答案：'} ${esc(x.p)}｜${esc(x.zh)}<br><small>${esc(x.ex)}</small>${!ok&&store.phKnown.includes(x.id)?'<br><small>已排入今天複習</small>':''}`;
    bumpLog('quiz');
    markStudy();
    save();
    say(x.p,.95)
  }
}
/* ===== V5.16.17 Priority 5：TWDC CE 情境對話 ===== */
const DIALOGS=window.DIALOGS||[];
const DLG_BY={};
DIALOGS.forEach(d=>DLG_BY[d.id]=d);
store.dlgDone=store.dlgDone&&typeof store.dlgDone==='object'&&!Array.isArray(store.dlgDone)?store.dlgDone:{};
const DLG={cur:null,zh:false,slow:false,tok:0,playing:-1,run:false};
function dlgVoices(){
  const b=pickVoice();
  const others=voices.filter(v=>!b||v.voiceURI!==b.voiceURI);
  const us=others.filter(v=>/en[-_]US/i.test(v.lang));
  return {A:us[0]||others[0]||b||null,B:b||null}
}
function sayV(t,rate,v,done){
  try{
    speechSynthesis.cancel()
  }catch(e){}
  const u=new SpeechSynthesisUtterance(t);
  u.lang='en-US';
  u.rate=rate;
  if(v){
    u.voice=v;
    u.lang=v.lang
  }
  let fin=false;
  const end=()=>{
    if(fin)return;
    fin=true;
    done&&done()
  };
  u.onend=end;
  u.onerror=end;
  speechSynthesis.speak(u);/* 保護：部分手機不會觸發 onend */
  setTimeout(()=>{
    if(!speechSynthesis.speaking)end()
  },Math.max(2500,t.length*140/rate))
}
function dlgStop(){
  DLG.tok++;
  DLG.playing=-1;
  DLG.run=false;
  try{
    speechSynthesis.cancel()
  }catch(e){}
  dlgMark();
  const b=$('#dlgPlayAll');
  if(b)b.textContent='▶ 播放整段'
}
function dlgMark(){
  document.querySelectorAll('#dialogBody .dlg-line').forEach(el=>el.classList.toggle('dlg-now',+el.dataset.n===DLG.playing))
}
function dlgPlayLine(d,n,rate,done){
  const L=d.lines[n];
  if(!L){
    done&&done();
    return
  }
  const V=dlgVoices();
  DLG.playing=n;
  dlgMark();
  const el=document.querySelector(`#dialogBody .dlg-line[data-n="${n}"]`);
  if(el&&el.scrollIntoView)el.scrollIntoView({block:'nearest',behavior:'smooth'});
  sayV(L.en,rate,L.s==='A'?V.A:V.B,()=>{
    if(DLG.playing===n){
      DLG.playing=-1;
      dlgMark()
    }
    done&&done()
  })
}
function dlgPlayAll(){
  const d=DLG.cur;
  if(!d)return;
  if(DLG.run){
    dlgStop();
    return
  }
  dlgStop();
  const tok=++DLG.tok;
  DLG.run=true;
  const rate=DLG.slow?.7:.95;
  $('#dlgPlayAll').textContent='■ 停止';
  let n=0;
  const next=()=>{
    if(tok!==DLG.tok)return;
    if(n>=d.lines.length){
      DLG.playing=-1;
      DLG.run=false;
      dlgMark();
      const pb=$('#dlgPlayAll');
      if(pb)pb.textContent='▶ 播放整段';
      return
    }
    dlgPlayLine(d,n++,rate,()=>{
      if(tok===DLG.tok)setTimeout(next,450)
    })
  };
  next()
}
function renderDialogs(){
  const box=$('#dialogBody');
  if(!box)return;
  dlgStop();
  if(DLG.cur){
    renderDialog(DLG.cur);
    return
  }
  const done=Object.keys(store.dlgDone).filter(k=>DLG_BY[k]).length;
  box.innerHTML=`<p class="muted">TWDC CE 現場常用的 ${DIALOGS.length} 個情境。點一個情境開始：先聽整段、再逐句跟讀；B 是你的角色。</p><div class="word-stats"><span>已練習 <b>${done}</b> / ${DIALOGS.length}</span><span>共 <b>${DIALOGS.reduce((a,d)=>a+d.lines.length,0)}</b> 句</span></div>`+
 DIALOGS.map((d,k)=>`<div class="dlg-card${store.dlgDone[d.id]?' dlg-done':''}" data-d="${esc(d.id)}"><span class="dlg-no">${k+1}</span><span class="dlg-main"><b>${esc(d.t)}</b> <small>${esc(d.te)}</small><small class="dlg-desc">${esc(d.desc)}</small></span><span class="dlg-tick">${store.dlgDone[d.id]?'✓':'›'}</span></div>`).join('')
}
function renderDialog(d){
  const box=$('#dialogBody');
  const dn=store.dlgDone[d.id];
  box.innerHTML=`<button id="dlgBack" class="mini">← 情境列表</button><h3 class="dlg-title">${esc(d.t)} <small>${esc(d.te)}</small></h3><p class="dlg-sit">${esc(d.desc)}</p>
 <div class="dlg-roles"><span class="dlg-a">A　${esc(d.roles.A)}</span><span class="dlg-b">B　${esc(d.roles.B)}</span></div>
 <div class="grid2 dlg-tools"><button id="dlgPlayAll" class="primary">${DLG.run?'■ 停止':'▶ 播放整段'}</button><button id="dlgSlow">🐢 慢速：${DLG.slow?'開':'關'}</button><button id="dlgZh">👁 ${DLG.zh?'隱藏中文':'顯示中文'}</button><button id="dlgShadow">🗣 逐句跟讀／錄音</button><button id="dlgRpB" class="rp-btn">🎭 Role Play：我演 B</button><button id="dlgRpA" class="rp-btn">🎭 Role Play：我演 A</button></div>${store.rpDone[d.id]?`<p class="muted rp-last">上次 Role Play：${esc(store.rpDone[d.id].d)}，演 ${esc(store.rpDone[d.id].me)}${store.rpDone[d.id].avg!=null?'，平均 '+store.rpDone[d.id].avg+'%':''}</p>`:''}
 <div class="dlg-lines">${d.lines.map((L,n)=>`<div class="dlg-line dlg-${L.s==='A'?'a':'b'}" data-n="${n}"><div class="dlg-bub"><b class="dlg-who">${L.s}</b><span class="dlg-en">${esc(L.en)}</span><span class="dlg-zh"${DLG.zh?'':' hidden'}>${esc(L.zh)}</span></div><span class="dlg-btns"><button data-play="${n}" aria-label="播放">🔊</button><button data-slow="${n}" aria-label="慢速">🐢</button></span></div>`).join('')}</div>
 <h3>重點句型 KEY PHRASES</h3><div class="dlg-keys">${(d.keys||[]).map(k=>`<div class="dlg-key"><span><b>${esc(k.en)}</b><small>${esc(k.zh)}</small></span><button data-say="${esc(k.en)}">🔊</button></div>`).join('')}</div>
 <button id="dlgDone" class="wide ${dn?'g3':''}">${dn?'✓ 已練習（'+esc(dn)+'）— 再按一次取消':'✓ 標記這個情境已練習'}</button>
 <div class="grid2 bottom"><button id="dlgPrev">← 上一個情境</button><button id="dlgNext">下一個情境 →</button></div>`;
  window.scrollTo(0,0);
  $('#dlgBack').onclick=()=>{
    DLG.cur=null;
    renderDialogs()
  };
  $('#dlgPlayAll').onclick=dlgPlayAll;
  $('#dlgSlow').onclick=()=>{
    DLG.slow=!DLG.slow;
    $('#dlgSlow').textContent='🐢 慢速：'+(DLG.slow?'開':'關')
  };
  $('#dlgZh').onclick=()=>{
    DLG.zh=!DLG.zh;
    box.querySelectorAll('.dlg-zh').forEach(e=>e.hidden=!DLG.zh);
    $('#dlgZh').textContent='👁 '+(DLG.zh?'隱藏中文':'顯示中文')
  };
  $('#dlgRpB').onclick=()=>rpStart(d,'B');
  $('#dlgRpA').onclick=()=>rpStart(d,'A');
  $('#dlgShadow').onclick=()=>{
    dlgStop();
    const u=$('#unit');
    u.value=d.id;
    store.settings.unit=d.id;
    save();
    page('practice');
    i=0;
    filter();
    if(!pool.some(s=>s.dlg===d.id)){
      $('#hideKnown').checked=false;
      filter()
    }
    render()
  };
  $('#dlgDone').onclick=()=>{
    if(store.dlgDone[d.id])delete store.dlgDone[d.id];else{
      store.dlgDone[d.id]=day();
      markStudy();
      bumpLog('dlg')
    }
    save();
    renderDialog(d)
  };
  const k=DIALOGS.indexOf(d);
  $('#dlgPrev').onclick=()=>{
    dlgStop();
    DLG.cur=DIALOGS[(k-1+DIALOGS.length)%DIALOGS.length];
    renderDialog(DLG.cur)
  };
  $('#dlgNext').onclick=()=>{
    dlgStop();
    DLG.cur=DIALOGS[(k+1)%DIALOGS.length];
    renderDialog(DLG.cur)
  }
}
$('#dialogBody').addEventListener('click',e=>{
  const c=e.target.closest('.dlg-card');
  if(c){
    DLG.cur=DLG_BY[c.dataset.d];
    renderDialog(DLG.cur);
    return
  }
  const p=e.target.closest('[data-play]'),sl=e.target.closest('[data-slow]'),k=e.target.closest('[data-say]');
  if(p||sl){
    dlgStop();
    DLG.tok++;
    dlgPlayLine(DLG.cur,+(p||sl).dataset[p?'play':'slow'],p?(DLG.slow?.7:.95):.6);
    return
  }
  if(k){
    dlgStop();
    sayV(k.dataset.say,DLG.slow?.7:.9,dlgVoices().B);
    return
  }
  const bub=e.target.closest('.dlg-bub');
  if(bub&&!DLG.zh){
    const z=bub.querySelector('.dlg-zh');
    if(z)z.hidden=!z.hidden
  }
});
$('#navDialogs').onclick=()=>{
  page('dialogs');
  renderDialogs()
};
/* ===== V5.16.18 Priority 6：Role Play（用句子頁的 🎤 辨識與 🎙 錄音） =====
   V5.16.19：🎤／🎙 按鈕移進 Role Play 區塊（不用往下捲）；連續模式：對方說完自動開始聆聽、念到 80% 以上自動下一句 */
store.rpDone=store.rpDone&&typeof store.rpDone==='object'&&!Array.isArray(store.rpDone)?store.rpDone:{};
const RP={on:false,d:null,me:'B',n:-1,sc:{},peek:false,tok:0,fin:false,docked:false,autoT:null};
function rpMine(){
  return RP.d?RP.d.lines.map((L,n)=>L.s===RP.me?n:-1).filter(n=>n>=0):[]
}
function rpSave(){
  try{
    if(RP.on)sessionStorage.setItem('e5k_rp',JSON.stringify({id:RP.d.id,me:RP.me,n:RP.n,sc:RP.sc}));else sessionStorage.removeItem('e5k_rp')
  }catch(e){}
}
function rpVoice(s){
  const V=dlgVoices();
  return s==='A'?V.A:V.B
}
function rpAutoOn(){
  return !!(store.settings&&store.settings.rpAuto)
}
function rpNodes(){
  const r=$('#record');
  return [$('#check'),$('#result'),r&&r.parentElement,$('#recMsg')].filter(Boolean)
}
function rpDock(on){
  const sp=$('#rpSpeak');
  if(!sp)return;
  if(on&&!RP.docked){
    const ns=rpNodes();
    let ph=$('#rpPH');
    if(!ph){
      ph=document.createElement('span');
      ph.id='rpPH';
      ph.hidden=true;
      ns[0].before(ph)
    }
    ns.forEach(n=>sp.appendChild(n));
    RP.docked=true
  }
 else if(!on&&RP.docked){
    const ph=$('#rpPH');
    if(ph)ph.after(...rpNodes());
    RP.docked=false
  }
}
function rpShowPractice(show){
  $('.sentence').hidden=!show;
  $('.panel').hidden=!show;
  $('.tip').hidden=!show;
  const hk=$('#hideKnown');
  if(hk)hk.disabled=!show
}
/* V5.16.20：Role Play 進行中回到句子頁時維持 Role Play 畫面；已完成的 Role Play 直接結束 */
window.rpAfterPage=()=>{
  if(!RP.on)return;
  if(RP.fin)rpOff();else rpShowPractice(false)
};
function rpStart(d,me,n,sc,resume){
  if(!d)return;
  dlgStop();
  RP.on=true;
  RP.fin=false;
  RP.d=d;
  RP.me=me==='A'?'A':'B';
  RP.sc=sc||{};
  const hk=$('#hideKnown');
  if(hk)hk.checked=false;
  $('#unit').value=d.id;
  page('practice');
  filter();
  const mine=rpMine();
  rpGo(n!=null&&mine.includes(n)?n:mine[0],!resume)
}
function rpGo(n,speak){
  clearTimeout(RP.autoT);
  RP.n=n;
  RP.peek=false;
  RP.fin=false;
  RP.tok++;
  const k=pool.findIndex(s=>s.id==='d:'+RP.d.id+':'+n);
  if(k>=0)i=k;
  rpSave();
  render();
  window.scrollTo(0,0);
  if(speak)rpPartner()
}
function rpPartnerLines(n){
  const mine=rpMine();
  const k=mine.indexOf(n);
  const from=k>0?mine[k-1]+1:0;
  const out=[];
  for(let j=from;j<n;j++)out.push(j);
  return out
}
function rpMark(j){
  document.querySelectorAll('#rpBox .rp-line').forEach(e=>e.classList.toggle('dlg-now',+e.dataset.n===j))
}
function rpPlay(list,done){
  clearTimeout(RP.autoT);
  const t=++RP.tok;
  let q=0;
  if(VOICE.srBusy)srAbort();
  recStopPlayback();
  const nx=()=>{
    if(t!==RP.tok||!RP.on)return;
    if(q>=list.length){
      rpMark(-1);
      done&&done();
      return
    }
    const j=list[q++],L=RP.d.lines[j];
    rpMark(j);
    sayV(L.en,DLG.slow?.75:.95,rpVoice(L.s),()=>setTimeout(nx,250))
  };
  nx()
}
function rpListenAuto(){
  const n=RP.n,t=RP.tok;
  clearTimeout(RP.autoT);
  RP.autoT=setTimeout(()=>{
    if(!RP.on||RP.fin||RP.n!==n||RP.tok!==t||VOICE.srBusy||REC.state!=='idle')return;
    const s=VOICE.sess;
    if(s&&!s.__dead&&SR){
      $('#check').click()
    }else{
      const r=$('#result');
      if(r)r.textContent='👉 輪到你了：按「🎤 開始念」（連續模式要先按一次 🎤，之後就會自動聆聽）'
    }
  },1000)
}
function rpPartner(){
  rpPlay(rpPartnerLines(RP.n),()=>{
    const r=$('#result');
    if(!RP.on||RP.fin)return;
    if(r)r.textContent='👉 輪到你了：看中文提示，按「🎤 開始念」說出你的台詞';
    if(rpAutoOn())rpListenAuto()
  })
}
function rpOff(){
  if(!RP.on)return;
  clearTimeout(RP.autoT);
  rpDock(false);
  RP.on=false;
  RP.fin=false;
  RP.tok++;
  try{
    speechSynthesis.cancel()
  }catch(e){}
  rpSave();
  const b=$('#rpBox');
  if(b){
    b.hidden=true;
    ['#rpTop','#rpBottom'].forEach(s=>{
      const e=$(s);
      if(e)e.innerHTML=''
    })
  }
  rpShowPractice(true);
  const se=$('.sentence');
  if(se)se.classList.remove('rp-hide');
  document.body.classList.remove('rp-mode');
  const hk=$('#hideKnown');
  if(hk&&hk.checked!==!!store.settings.hideKnown){
    hk.checked=!!store.settings.hideKnown;
    refilter()
  }
}
function rpAvg(){
  const v=rpMine().map(n=>RP.sc[n]).filter(x=>typeof x==='number');
  return v.length?Math.round(v.reduce((a,b)=>a+b,0)/v.length):null
}
function rpProg(){
  const mine=rpMine(),k=mine.indexOf(RP.n);
  return `你的台詞 ${k+1} / ${mine.length}${RP.sc[RP.n]!=null?'｜這句最高 '+RP.sc[RP.n]+'%':''}`
}
function rpPeekSet(v){
  RP.peek=v;
  const e=$('#rpEn');
  if(e)e.classList.toggle('rp-blur',!v);
  const se=$('.sentence');
  if(se)se.classList.toggle('rp-hide',!v);
  const p=$('#rpPeek');
  if(p)p.textContent=v?'🙈 隱藏英文':'👁 看英文'
}
function rpRender(s){
  const box=$('#rpBox');
  if(!box)return;
  if(!RP.on){
    box.hidden=true;
    return
  }
  if(RP.fin){
    rpOff();
    render();
    return
  }
  const m=/^d:(d\d\d):(\d+)$/.exec(s.id||'');
  if(!m||m[1]!==RP.d.id||RP.d.lines[+m[2]].s!==RP.me){
    rpOff();
    render();
    return
  }
  RP.n=+m[2];
  const d=RP.d,mine=rpMine(),k=mine.indexOf(RP.n),other=RP.me==='A'?'B':'A';
  document.body.classList.add('rp-mode');
  const hist=[];
  for(let j=Math.max(0,RP.n-2);j<RP.n;j++)hist.push(j);
  box.hidden=false;
  rpShowPractice(false);
  rpDock(true);
  $('#rpTop').innerHTML=`<div class="rp-head"><span><b>🎭 Role Play：${esc(d.t)}</b><small>你演 ${RP.me}：${esc(d.roles[RP.me])}｜對方 ${other}：${esc(d.roles[other])}</small></span><button id="rpEnd" class="mini">✕ 結束</button></div>
 <div class="rp-progrow"><span class="rp-prog">${rpProg()}</span>${k>0?'<button id="rpPrev" class="mini">← 上一句</button>':''}</div>
 <div class="rp-hist">${RP.n>2?'<small class="muted">…（點對話框看中文）</small>':''}${hist.map(j=>{
    const L=d.lines[j];
    return `<div class="dlg-line rp-line dlg-${L.s==='A'?'a':'b'}" data-n="${j}"><div class="dlg-bub"><b class="dlg-who">${L.s}${L.s===RP.me?'（你）':''}</b><span class="dlg-en">${esc(L.en)}</span><span class="dlg-zh" hidden>${esc(L.zh)}</span></div><span class="dlg-btns"><button data-rpsay="${j}" aria-label="播放">🔊</button></span></div>`
  }).join('')}</div>
 <div class="rp-turn">🗣 輪到你（${RP.me}）說：<b>${esc(s.zh)}</b><div id="rpEn" class="rp-en${RP.peek?'':' rp-blur'}">${esc(s.en)}</div></div>`;
  $('#rpBottom').innerHTML=`<div class="grid2 rp-tools"><button id="rpHear">🔁 再聽對方</button><button id="rpAns">🔊 標準答案</button><button id="rpPeek">${RP.peek?'🙈 隱藏英文':'👁 看英文'}</button><button id="rpNext" class="primary">${k+1<mine.length?'下一句 →':'完成 ✓'}</button></div>
 <label class="hk rp-auto"><input type="checkbox" id="rpAuto"${rpAutoOn()?' checked':''}> 連續模式：對方說完自動開始聆聽，念到 80% 以上自動下一句</label>`;
  const se=$('.sentence');
  if(se)se.classList.toggle('rp-hide',!RP.peek);
  $('#chinese').hidden=false;
  $('#result').textContent=rpPartnerLines(RP.n).length?'🔊 先聽對方說，再按「🎤 開始念」說出你的台詞':'👉 你先開口：按「🎤 開始念」說出你的台詞';
  $('#rpEnd').onclick=()=>{
    const dd=RP.d;
    rpOff();
    page('dialogs');
    DLG.cur=dd;
    renderDialog(dd)
  };
  const pv=$('#rpPrev');
  if(pv)pv.onclick=()=>rpNav(-1);
  $('#rpHear').onclick=()=>{
    const ls=rpPartnerLines(RP.n);
    if(!ls.length&&!RP.n){
      $('#result').textContent='👉 這句是你先開口，前面沒有對方的台詞';
      return
    }
    rpPlay(ls.length?ls:[RP.n-1],()=>{
      if(rpAutoOn())rpListenAuto()
    })
  };
  $('#rpAns').onclick=()=>{
    clearTimeout(RP.autoT);
    RP.tok++;
    if(VOICE.srBusy)srAbort();
    recStopPlayback();
    sayV(s.en,DLG.slow?.75:.9,rpVoice(RP.me))
  };
  $('#rpPeek').onclick=()=>rpPeekSet(!RP.peek);
  $('#rpNext').onclick=()=>rpNav(1);
  $('#rpAuto').onchange=e=>{
    store.settings.rpAuto=e.target.checked;
    save();
    if(!e.target.checked)clearTimeout(RP.autoT)
  };
  box.querySelectorAll('[data-rpsay]').forEach(b=>b.onclick=()=>rpPlay([+b.dataset.rpsay]));
  box.querySelectorAll('.rp-line .dlg-bub').forEach(b=>b.onclick=()=>{
    const z=b.querySelector('.dlg-zh');
    if(z)z.hidden=!z.hidden
  })
}
function rpNav(dir){
  if(!RP.on)return false;
  if(RP.fin){
    rpOff();
    return false
  }
  const mine=rpMine(),k=mine.indexOf(RP.n);
  if(dir>0){
    if(k+1<mine.length)rpGo(mine[k+1],true);else rpFinish()
  }else{
    if(k>0)rpGo(mine[k-1],false)
  }
  return true
}
function rpScore(score){
  if(!RP.on||RP.fin)return;
  RP.sc[RP.n]=Math.max(RP.sc[RP.n]||0,score);
  rpPeekSet(true);
  const g=$('#rpBox .rp-prog');
  if(g)g.textContent=rpProg();
  rpSave();
  const r=$('#result');
  const auto=rpAutoOn()&&score>=80;
  if(r)r.insertAdjacentHTML('beforeend',auto?'<br><small>👍 連續模式：1.5 秒後自動下一句…</small>':'<br><small>可以按「🎙 重新錄音」或「🎤」再試一次；滿意就按「下一句 →」。</small>');
  if(auto){
    const n=RP.n,t=RP.tok;
    clearTimeout(RP.autoT);
    RP.autoT=setTimeout(()=>{
      if(RP.on&&!RP.fin&&RP.n===n&&RP.tok===t&&!VOICE.srBusy&&REC.state==='idle')rpNav(1)
    },1500)
  }
}
function rpFinish(){
  clearTimeout(RP.autoT);
  const d=RP.d,mine=rpMine(),last=mine[mine.length-1],rest=[];
  for(let j=last+1;j<d.lines.length;j++)rest.push(j);
  RP.fin=true;
  rpSave();
  const avg=rpAvg(),said=mine.filter(n=>RP.sc[n]!=null).length;
  store.rpDone[d.id]={d:day(),me:RP.me,avg:avg};
  markStudy();
  bumpLog('rp');
  save();
  rpDock(false);
  rpShowPractice(false);
  const box=$('#rpBox');
  box.hidden=false;
  $('#rpBottom').innerHTML='';
  $('#rpTop').innerHTML=`<div class="rp-head"><span><b>🎉 完成 Role Play：${esc(d.t)}</b><small>你演 ${RP.me}：${esc(d.roles[RP.me])}</small></span></div>
 <p class="rp-sum">你的台詞 ${mine.length} 句，用 🎤 檢查了 ${said} 句${avg!=null?'，平均相似度 <b>'+avg+'%</b>':''}。</p>
 <div class="rp-scores">${mine.map(n=>`<div class="rp-sc"><span>${esc(d.lines[n].en)}</span><b>${RP.sc[n]!=null?RP.sc[n]+'%':'—'}</b></div>`).join('')}</div>
 <div class="grid2 rp-tools"><button id="rpAgain" class="primary">🔁 再演一次</button><button id="rpSwap">🔄 換演 ${RP.me==='A'?'B':'A'}</button><button id="rpBackD" class="span2">← 回到對話</button></div>`;
  window.scrollTo(0,0);
  $('#rpAgain').onclick=()=>rpStart(d,RP.me);
  $('#rpSwap').onclick=()=>rpStart(d,RP.me==='A'?'B':'A');
  $('#rpBackD').onclick=()=>{
    rpOff();
    page('dialogs');
    DLG.cur=d;
    renderDialog(d)
  };
  if(rest.length)rpPlay(rest)
}
window.rpRender=rpRender;
window.rpNav=rpNav;
window.rpScore=rpScore;
window.rpOff=rpOff;
try{
  const rp=JSON.parse(sessionStorage.getItem('e5k_rp')||'null');
  const srNote=sessionStorage.getItem('e5k_sr')==='1';
  if(rp&&sessionStorage.getItem('e5k_go')==='practice'&&DLG_BY[rp.id])setTimeout(()=>{
    const note=srNote||/麥克風已重新啟動/.test($('#result').textContent);
    rpStart(DLG_BY[rp.id],rp.me,rp.n,rp.sc,true);
    $('#result').textContent=note?'✅ 麥克風已重新啟動，請再按一次「🎤 開始念」。':'👉 繼續 Role Play：按「🎤 開始念」說出你的台詞'
  },0);else sessionStorage.removeItem('e5k_rp')
}catch(e){}

/* ===== V5.16.18 Priority 6：新測驗（聽力、對話填空、CE 情境題） ===== */
const SITQ=window.SITQ||[];
function qShuffle(a){
  a=a.slice();
  for(let k=a.length-1;k>0;k--){
    const j=Math.floor(Math.random()*(k+1));
    [a[k],a[j]]=[a[j],a[k]]
  }
  return a
}
function qRange(){
  const r=($('#quizSRange')||{}).value||'cd';
  const cd=ALLS.filter(s=>s.src==='core'||s.src==='dialog');
  if(r==='wrong'){
    const w=store.lsWrong||{};
    return {q:ALLS.filter(s=>w[s.id]),base:cd}
  }
  const q=r==='dlg'?ALLS.filter(s=>s.src==='dialog'):r==='all'?ALLS:cd;
  return {q,base:q}
}
function qEmpty(t){
  $('#quizQ').innerHTML=t;
  $('#quizOpts').innerHTML='';
  $('#quizMsg').textContent='';
  $('#quizOpts').onclick=null
}
/* V5.16.19：聽力題、對話填空答錯 → 加入「📕 測驗答錯的句子」；標過「會說」的句子排入今天的 🔁 待複習 */
function qWrongMark(id,ok){
  store.lsWrong=store.lsWrong&&typeof store.lsWrong==='object'?store.lsWrong:{};
  if(ok){
    if(store.lsWrong[id]){
      delete store.lsWrong[id];
      save();
      return '<br><small>已從「📕 測驗答錯的句子」移除</small>'
    }
    return ''
  }
  store.lsWrong[id]=(store.lsWrong[id]||0)+1;
  let note='已加入「📕 測驗答錯的句子」（句子頁、測驗都可以只練答錯的）';
  if(cset('known').has(id)){
    store.sDue=store.sDue||{};
    store.sStage=store.sStage||{};
    store.sDue[id]=day();
    store.sStage[id]=1;
    note='這句你標過「會說」，已排入今天的 🔁 待複習句子，也加入「📕 測驗答錯的句子」'
  }
  save();
  return '<br><small>'+note+'</small>'
}
function qNear(x,pool,key,n){
  const L=x[key].length;
  const c=pool.filter(y=>y.id!==x.id&&y[key]&&y[key]!==x[key]&&y.en!==x.en);
  let near=c.filter(y=>Math.abs(y[key].length-L)<=Math.max(4,L*.35));
  if(near.length<n*3)near=c;
  const out=[];
  const seen=new Set([x[key]]);
  for(const y of qShuffle(near.length>400?near.slice(0,400).concat(qShuffle(near).slice(0,200)):near)){
    if(seen.has(y[key]))continue;
    seen.add(y[key]);
    out.push(y);
    if(out.length>=n)break
  }
  return out
}
function qCount(ok){
  store[ok?'quizRight':'quizWrong']=(store[ok?'quizRight':'quizWrong']||0)+1;
  bumpLog('quiz');
  markStudy();
  save()
}
function qPick(opts,isOk,after){
  let done=false;
  $('#quizOpts').onclick=e=>{
    const b=e.target.closest('button[data-k]');
    if(!b||done)return;
    done=true;
    const ok=isOk(+b.dataset.k);
    b.classList.add(ok?'opt-ok':'opt-bad');
    if(!ok){
      const c=[...$('#quizOpts').querySelectorAll('button[data-k]')].find(x=>isOk(+x.dataset.k));
      if(c)c.classList.add('opt-ok')
    }
    qCount(ok);
    after(ok,+b.dataset.k)
  }
}
function lisEnQuiz(){
  const R=qRange();
  if(!R.q.length){
    qEmpty('🎉 沒有答錯的句子');
    return
  }
  const x=R.q[Math.floor(Math.random()*R.q.length)];
  const opts=qShuffle([x,...qNear(x,R.base,'zh',3)]);
  const rate=()=>.9;
  $('#quizQ').innerHTML=`🎧 聽英文句子，選出正確的中文意思<br><button id="quizReplay">🔊 再聽</button> <button id="quizSlow">🐢 慢速</button>`;
  $('#quizMsg').textContent='';
  $('#quizOpts').innerHTML=opts.map((o,k)=>`<button data-k="${k}">${esc(o.zh)}</button>`).join('');
  say(x.en,rate());
  $('#quizReplay').onclick=()=>say(x.en,.9);
  $('#quizSlow').onclick=()=>say(x.en,.65);
  qPick(opts,k=>opts[k].id===x.id,ok=>{
    $('#quizMsg').innerHTML=`${ok?'✅ 答對了！':'❌ 正確答案如上（綠色）'}<br><b>${esc(x.en)}</b><br><small>${esc(x.zh)}${x.src==='dialog'?'｜'+esc(SRC_LABEL.dialog)+'：'+esc((DLG_BY[x.dlg]||{}).t||''):''}</small>`+qWrongMark(x.id,ok)
  })
}
function lisZhQuiz(){
  const R=qRange();
  if(!R.q.length){
    qEmpty('🎉 沒有答錯的句子');
    return
  }
  const x=R.q[Math.floor(Math.random()*R.q.length)];
  const opts=qShuffle([x,...qNear(x,R.base,'en',3)]);
  let sel=-1;
  $('#quizQ').innerHTML=`🎧 看中文，聽 4 個英文選項，選出意思相同的那一句<br><b class="lz-zh">${esc(x.zh)}</b>`;
  $('#quizMsg').textContent='先點 🔊 聽每個選項，再選答案。';
  $('#quizOpts').innerHTML=opts.map((o,k)=>`<div class="lz-row"><button class="lz-play" data-p="${k}">🔊 選項 ${k+1}</button><button class="lz-pick" data-k="${k}">選這個</button><span class="lz-en" hidden>${esc(o.en)}</span></div>`).join('');
  let done=false;
  $('#quizOpts').onclick=e=>{
    const p=e.target.closest('[data-p]');
    if(p){
      const k=+p.dataset.p;
      sel=k;
      $('#quizOpts').querySelectorAll('.lz-play').forEach(b=>b.classList.toggle('lz-on',+b.dataset.p===k));
      say(opts[k].en,.9);
      return
    }
    const b=e.target.closest('button[data-k]');
    if(!b||done)return;
    done=true;
    const k=+b.dataset.k,ok=opts[k].id===x.id;
    b.classList.add(ok?'opt-ok':'opt-bad');
    $('#quizOpts').querySelectorAll('.lz-en').forEach(s=>s.hidden=false);
    if(!ok){
      const c=$('#quizOpts').querySelector(`button[data-k="${opts.indexOf(x)}"]`);
      if(c)c.classList.add('opt-ok')
    }
    qCount(ok);
    $('#quizMsg').innerHTML=`${ok?'✅ 答對了！':'❌ 正確答案是選項 '+(opts.indexOf(x)+1)}<br><b>${esc(x.en)}</b><br><small>${esc(x.zh)}</small>`+qWrongMark(x.id,ok);
    say(x.en,.9)
  }
}
const DC_STOP=new Set('the a an and or but to of in on at for with from by is are was were be been am it its it\'s this that these those i you we they he she me us them my your our their can could will would should do does did have has had not no yes ok okay please there here what which who when where how just so if then than also all any some one two let\'s let i\'m you\'re we\'re that\'s don\'t can\'t won\'t i\'ll we\'ll you\'ll go get got up out now right sure thanks thank hi hello'.split(' '));
function dcWords(t){
  return (t.match(/[A-Za-z][A-Za-z0-9'-]*/g)||[]).filter(w=>w.length>=3&&!DC_STOP.has(w.toLowerCase()))
}
let _dcPool=null;
function dcPool(){
  if(_dcPool)return _dcPool;
  const ws=new Map();
  DIALOGS.forEach(d=>d.lines.forEach(L=>dcWords(L.en).forEach(w=>{
    const k=w.toLowerCase();
    if(!ws.has(k))ws.set(k,w)
  })));
  _dcPool=[...ws.values()];
  return _dcPool
}
function dcQuiz(){
  if(!DIALOGS.length){
    $('#quizQ').textContent='沒有對話資料';
    $('#quizOpts').innerHTML='';
    return
  }
  let d,n,cand;
  const wOnly=($('#quizDcRange')||{}).value==='wrong';
  const wl=Object.keys(store.lsWrong||{}).map(id=>/^d:(d\d\d):(\d+)$/.exec(id)).filter(m=>m&&DLG_BY[m[1]]&&DLG_BY[m[1]].lines[+m[2]]&&dcWords(DLG_BY[m[1]].lines[+m[2]].en).length);
  if(wOnly&&!wl.length){
    qEmpty('🎉 沒有答錯的對話句');
    return
  }
  for(let t=0;t<30;t++){
    if(wOnly){
      const m=wl[Math.floor(Math.random()*wl.length)];
      d=DLG_BY[m[1]];
      n=+m[2]
    }else{
      d=DIALOGS[Math.floor(Math.random()*DIALOGS.length)];
      n=1+Math.floor(Math.random()*(d.lines.length-1))
    }
    cand=dcWords(d.lines[n].en);
    if(cand.length)break
  }
  const keyTxt=(d.keys||[]).map(k=>k.en.toLowerCase()).join(' ');
  const pref=cand.filter(w=>/^[A-Z0-9-]{2,}$/.test(w)||keyTxt.includes(w.toLowerCase()));
  const ans=(pref.length?pref:cand.sort((a,b)=>b.length-a.length).slice(0,3))[Math.floor(Math.random()*Math.min(3,(pref.length||Math.min(3,cand.length))))]||cand[0];
  const isAc=/^[A-Z0-9-]{2,}$/.test(ans);
  const lineLow=d.lines[n].en.toLowerCase();
  let pool=dcPool().filter(w=>w.toLowerCase()!==ans.toLowerCase()&&!new RegExp('\\b'+w.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b').test(lineLow)&&(/^[A-Z0-9-]{2,}$/.test(w)===isAc));
  let near=pool.filter(w=>Math.abs(w.length-ans.length)<=2);
  if(near.length<3)near=pool;
  const opts=qShuffle([ans,...qShuffle(near).slice(0,3)]);
  const L=d.lines[n],P=d.lines[n-1]||null;
  const re=new RegExp('\\b'+ans.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\b');
  const reAll=new RegExp(re.source,'g');
  const blank=esc(L.en.replace(reAll,'\u0000')).split('\u0000').join('<span class="blank">_____</span>');
  $('#quizQ').innerHTML=`<small class="muted">💬 對話填空｜${esc(d.t)}</small><div class="dc-ctx">${P?`<div class="dc-l"><b>${P.s}</b> ${esc(P.en)}</div>`:'<div class="dc-l muted">（對話第一句）</div>'}<div class="dc-l dc-q"><b>${L.s}</b> ${blank}</div><small>${esc(L.zh)}</small></div>${P?'<button id="quizReplay">🔊 聽上一句</button>':''}`;
  $('#quizMsg').textContent='';
  const show=o=>/^[A-Z][a-z']+$/.test(o)?o.toLowerCase():o;
  $('#quizOpts').innerHTML=opts.map((o,k)=>`<button data-k="${k}">${esc(show(o))}</button>`).join('');
  const rb=$('#quizReplay');
  if(rb)rb.onclick=()=>say(P.en,.9);
  qPick(opts,k=>opts[k]===ans,ok=>{
    $('#quizMsg').innerHTML=`${ok?'✅ 答對了！':'❌ 正確答案：'+esc(ans)}<br><b>${esc(L.en)}</b><br><small>${esc(L.zh)}</small>`+qWrongMark('d:'+d.id+':'+n,ok);
    say(L.en,.9)
  })
}
function situQuiz(){
  if(!SITQ.length){
    $('#quizQ').textContent='沒有情境題資料';
    $('#quizOpts').innerHTML='';
    return
  }
  const sw=store.sqWrong||{};
  const wrongIds=SITQ.filter(q=>sw[q.id]);
  const useWrong=($('#quizSRange2')||{}).value==='wrong';
  if(useWrong&&!wrongIds.length){
    $('#quizQ').innerHTML='🎉 沒有答錯的情境題';
    $('#quizOpts').innerHTML='';
    $('#quizMsg').textContent='';
    return
  }
  const src=useWrong?wrongIds:SITQ;
  let q=src[Math.floor(Math.random()*src.length)];
  if(src.length>1&&q.id===store.sqLast)q=src[(src.indexOf(q)+1)%src.length];
  store.sqLast=q.id;
  const ord=qShuffle([0,1,2,3]);
  $('#quizQ').innerHTML=`<small class="muted">🏭 CE 情境題｜${esc(q.topic||'')}</small><div class="sq-sit">${esc(q.sit)}</div>`;
  $('#quizMsg').textContent='';
  $('#quizOpts').innerHTML=ord.map((o,k)=>`<button data-k="${k}" class="sq-opt">${esc(q.opts[o])}</button>`).join('');
  qPick(ord,k=>ord[k]===q.ans,(ok,k)=>{
    store.sqWrong=store.sqWrong||{};
    if(ok)delete store.sqWrong[q.id];else store.sqWrong[q.id]=(store.sqWrong[q.id]||0)+1;
    save();
    $('#quizOpts').querySelectorAll('button[data-k]').forEach(b=>{
      const o=ord[+b.dataset.k];
      b.insertAdjacentHTML('beforeend',`<small class="sq-zh">${esc(q.zh[o])}</small>`)
    });
    $('#quizMsg').innerHTML=`${ok?'✅ 答對了！':'❌ 最適合的說法是綠色那一句'}<br><small>${esc(q.why)}</small><br><button id="sqSay">🔊 聽正確說法</button>`;
    const go=()=>say(q.opts[q.ans],.9);
    $('#sqSay').onclick=go;
    go()
  })
}
window.P6QUIZ={lisen:lisEnQuiz,liszh:lisZhQuiz,dcloze:dcQuiz,situ:situQuiz};
['quizSRange','quizSRange2','quizDcRange'].forEach(id=>{
  const e=$('#'+id);
  if(e)e.onchange=runQuiz
});
(function(){
  const g=$('#dlgUnits');
  if(g&&DIALOGS.length){
    const n=ALLS.filter(x=>x.src==='dialog').length;
    g.innerHTML=`<option value="dall">對話句・全部（${n}）</option>`+DIALOGS.map((d,k)=>`<option value="${esc(d.id)}">對話 ${k+1}・${esc(d.t)}</option>`).join('')
  }else if(g)g.remove();
  const ev=$('#unit option[value="every"]');
  if(ev)ev.textContent=`全部句子（${ALLS.length}）`
})();
window.addEventListener('beforeinstallprompt',e=>{
  e.preventDefault();
  deferred=e;
  $('#install').hidden=false
});
$('#install').onclick=()=>deferred&&deferred.prompt();
if('serviceWorker'in navigator){
  let swReloaded=false,hadCtl=!!navigator.serviceWorker.controller;
  navigator.serviceWorker.addEventListener('controllerchange',()=>{
    if(!hadCtl||swReloaded)return;
    const go=()=>{
      if(swReloaded)return;
      swReloaded=true;
      location.reload()
    };
    const busy=REC.state!=='idle'||VOICE.srBusy||RP.on||DLG.run||autoOn||cardAuto||$('#todayPage').hidden;
    if(!busy)go();else document.addEventListener('visibilitychange',()=>{
      if(document.hidden&&REC.state==='idle')go()
    })
  });
  navigator.serviceWorker.register('sw.js').then(reg=>{
    reg.update&&reg.update().catch(()=>{})
  }).catch(()=>{})
}
if(store.settings.unit&&[...$('#unit').options].some(o=>o.value===store.settings.unit))$('#unit').value=store.settings.unit;
$('#hideKnown').checked=!!store.settings.hideKnown;
i=(store.settings.pos||{})[$('#unit').value]||0;
filter();
render();
page('today');
renderToday();
try{
  const msg=sessionStorage.getItem('e5k_msg');
  if(sessionStorage.getItem('e5k_go')==='stats'){
    sessionStorage.removeItem('e5k_go');
    sessionStorage.removeItem('e5k_msg');
    page('stats');
    renderStats();
    fillVoices();
    verCheck();
    renderBackup();
    if(msg)backupMsg(msg)
  }
  if(window.__storeNote){
    page('stats');
    renderStats();
    renderBackup();
    backupMsg(window.__storeNote,'warn')
  }
}catch(e){}
try{
  if(sessionStorage.getItem('e5k_go')==='practice'){
    sessionStorage.removeItem('e5k_go');
    page('practice');
    if(sessionStorage.getItem('e5k_sr')==='1'){
      sessionStorage.removeItem('e5k_sr');
      $('#result').textContent='✅ 麥克風已重新啟動，請再按一次「🎤 開始念」。'
    }
  }
}catch(e){}
function verCheck(){
  const pv='V'+APP_VERSION,b=$('#appVer');
  const shown=HTML_VER;
  if(b)b.textContent=pv;
  const el=$('#verInfo');
  const put=c=>{
    if(!el)return;
    const okc=c==='english-5000-v'+APP_VERSION.replace(/\./g,'-');
    el.innerHTML='程式版本 '+pv+'　畫面 '+esc(shown||'?')+'<br>離線快取 '+esc(c||'（尚未建立）')+((shown&&shown!==pv)||(c&&!okc)?'<br><b style="color:#c62828">⚠️ 版本不一致：請關閉分頁後重新開啟</b>':'　✅ 一致')
  };
  if(window.caches&&caches.keys)caches.keys().then(k=>put(k.filter(x=>x.startsWith('english-5000')).join('、'))).catch(()=>put(''));else put('')
}
setTimeout(verCheck,0);
